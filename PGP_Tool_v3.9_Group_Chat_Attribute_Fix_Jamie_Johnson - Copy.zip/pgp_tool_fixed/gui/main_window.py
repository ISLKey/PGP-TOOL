"""
Main Window GUI Module
Creates the main application window with tabbed interface
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import sys
import time
import uuid
import random
import string
from typing import Optional

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import *
from crypto.key_generator import SecureKeyGenerator

# Try to import secure chat, but don't fail if it's not available
try:
    from chat.secure_chat import SecureChatHandler
    SECURE_CHAT_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Secure chat not available: {e}")
    SECURE_CHAT_AVAILABLE = False
    SecureChatHandler = None

class PGPToolMainWindow:
    """Main application window"""
    
    def __init__(self):
        """Initialize the main window"""
        self.root = tk.Tk()
        
        # Hide the window initially until authentication
        self.root.withdraw()
        
        self.setup_window()
        self.setup_styles()
        self.create_menu()
        self.create_main_interface()
        
        # Initialize crypto backend
        self.key_generator = SecureKeyGenerator(
            gnupg_home=os.path.join(DATA_DIR, "gnupg")
        )
        
        # Initialize message history data
        self.message_history_data = {}
        
        # Application state
        self.current_keys = []
        self.current_messages = []
        
    def setup_window(self):
        """Configure the main window"""
        self.root.title(f"{APP_NAME} v{APP_VERSION}")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.minsize(WINDOW_MIN_WIDTH, WINDOW_MIN_HEIGHT)
        
        # Center the window
        self.center_window()
        
        # Set window icon (if available)
        try:
            # You can add an icon file here
            pass
        except:
            pass
        
        # Handle window closing
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
    
    def center_window(self):
        """Center the window on screen"""
        self.root.update_idletasks()
        width = self.root.winfo_width()
        height = self.root.winfo_height()
        x = (self.root.winfo_screenwidth() // 2) - (width // 2)
        y = (self.root.winfo_screenheight() // 2) - (height // 2)
        self.root.geometry(f"{width}x{height}+{x}+{y}")
    
    def setup_styles(self):
        """Configure GUI styles"""
        style = ttk.Style()
        
        # Configure notebook (tab) style
        style.configure('TNotebook', background=COLORS['background'])
        style.configure('TNotebook.Tab', padding=[20, 10])
        
        # Configure button styles with solid backgrounds
        style.configure('Action.TButton', 
                       font=('Arial', 10, 'bold'),
                       padding=(10, 8))  # Added padding for better button size
        
        # Danger button (red) - for burn message
        style.configure('Danger.TButton', 
                       font=('Arial', 10, 'bold'),
                       foreground='white',
                       background=COLORS['error'],
                       borderwidth=0,
                       focuscolor='none',
                       padding=(15, 10))  # More padding for important button
        style.map('Danger.TButton',
                 background=[('active', '#c82333'),  # Darker red on hover
                            ('pressed', '#bd2130')])   # Even darker when pressed
        
        # Success button (green) - for encrypt message
        style.configure('Success.TButton', 
                       font=('Arial', 10, 'bold'),
                       foreground='white',
                       background=COLORS['success'],
                       borderwidth=0,
                       focuscolor='none',
                       padding=(15, 10))  # More padding for important button
        style.map('Success.TButton',
                 background=[('active', '#218838'),  # Darker green on hover
                            ('pressed', '#1e7e34')])   # Even darker when pressed
        
    def create_menu(self):
        """Create the application menu bar"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Import Key...", command=self.import_key_dialog)
        file_menu.add_command(label="Export Keys...", command=self.export_keys_dialog)
        file_menu.add_separator()
        file_menu.add_command(label="Create Backup...", command=self.create_backup_dialog)
        file_menu.add_command(label="Restore Backup...", command=self.restore_backup_dialog)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.on_closing)
        
        # Security menu
        security_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Security", menu=security_menu)
        security_menu.add_command(label="Emergency Kill Switch", command=self.emergency_kill_switch)
        security_menu.add_command(label="Clear All Data", command=self.clear_all_data)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="How We Built This", command=self.show_how_we_built_this)
        help_menu.add_separator()
        help_menu.add_command(label="About", command=self.show_about)
    
    def create_main_interface(self):
        """Create the main tabbed interface"""
        # Create main frame
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(0, weight=1)
        
        # Create notebook (tabbed interface)
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Create tabs
        self.create_keys_tab()
        self.create_contacts_tab()
        self.create_messages_tab()
        
        # Only create chat tab if secure chat is available
        if SECURE_CHAT_AVAILABLE:
            self.create_chat_tab()
        else:
            print("Secure chat not available - skipping chat tab")
        
        # Status bar
        self.create_status_bar(main_frame)
    
    def create_keys_tab(self):
        """Create the keys management tab"""
        keys_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(keys_frame, text="🔑 Keys")
        
        # Configure grid
        keys_frame.columnconfigure(1, weight=1)
        keys_frame.rowconfigure(1, weight=1)
        
        # Left panel - Key actions
        left_panel = ttk.LabelFrame(keys_frame, text="Key Actions", padding="10")
        left_panel.grid(row=0, column=0, rowspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        
        # Generate new key button
        ttk.Button(
            left_panel, 
            text="Generate New Key Pair", 
            command=self.generate_key_dialog,
            style='Action.TButton'
        ).pack(fill=tk.X, pady=5)
        
        # Import key button
        ttk.Button(
            left_panel, 
            text="Import Key", 
            command=self.import_key_dialog
        ).pack(fill=tk.X, pady=5)
        
        # Export selected key
        ttk.Button(
            left_panel, 
            text="Export Selected Key", 
            command=self.export_selected_key
        ).pack(fill=tk.X, pady=5)
        
        # Delete selected key (using same style as Emergency Kill button)
        delete_button = tk.Button(
            left_panel, 
            text="Delete Selected Key", 
            command=self.delete_selected_key,
            bg="#dc3545",  # Same red as Emergency Kill
            fg="white",    # White text
            font=("Arial", 9, "bold"),
            relief=tk.RAISED,
            bd=2,
            padx=10,
            pady=5
        )
        delete_button.pack(fill=tk.X, pady=5)
        
        # Separator
        ttk.Separator(left_panel, orient='horizontal').pack(fill=tk.X, pady=10)
        
        # Key info label
        ttk.Label(left_panel, text="Key Information:").pack(anchor=tk.W)
        
        # Key info text
        self.key_info_text = tk.Text(left_panel, height=8, width=30, wrap=tk.WORD)
        key_info_scroll = ttk.Scrollbar(left_panel, orient="vertical", command=self.key_info_text.yview)
        self.key_info_text.configure(yscrollcommand=key_info_scroll.set)
        self.key_info_text.pack(fill=tk.BOTH, expand=True, pady=5)
        key_info_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Right panel - Key list
        right_panel = ttk.LabelFrame(keys_frame, text="Your Keys", padding="10")
        right_panel.grid(row=0, column=1, rowspan=2, sticky=(tk.W, tk.E, tk.N, tk.S))
        right_panel.columnconfigure(0, weight=1)
        right_panel.rowconfigure(0, weight=1)
        
        # Key list with scrollbar
        key_list_frame = ttk.Frame(right_panel)
        key_list_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        key_list_frame.columnconfigure(0, weight=1)
        key_list_frame.rowconfigure(0, weight=1)
        
        # Treeview for key list
        self.key_tree = ttk.Treeview(
            key_list_frame, 
            columns=('Type', 'Name', 'Email', 'KeyID', 'Created'),
            show='tree headings'
        )
        
        # Configure columns
        self.key_tree.heading('#0', text='')
        self.key_tree.heading('Type', text='Type')
        self.key_tree.heading('Name', text='Name')
        self.key_tree.heading('Email', text='Email')
        self.key_tree.heading('KeyID', text='Key ID')
        self.key_tree.heading('Created', text='Created')
        
        self.key_tree.column('#0', width=30)
        self.key_tree.column('Type', width=80)
        self.key_tree.column('Name', width=150)
        self.key_tree.column('Email', width=200)
        self.key_tree.column('KeyID', width=120)
        self.key_tree.column('Created', width=100)
        
        # Scrollbars for key tree
        key_v_scroll = ttk.Scrollbar(key_list_frame, orient="vertical", command=self.key_tree.yview)
        key_h_scroll = ttk.Scrollbar(key_list_frame, orient="horizontal", command=self.key_tree.xview)
        self.key_tree.configure(yscrollcommand=key_v_scroll.set, xscrollcommand=key_h_scroll.set)
        
        # Grid the treeview and scrollbars
        self.key_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        key_v_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        key_h_scroll.grid(row=1, column=0, sticky=(tk.W, tk.E))
        
        # Bind selection event
        self.key_tree.bind('<<TreeviewSelect>>', self.on_key_selected)
        
        # Refresh keys button
        ttk.Button(
            right_panel, 
            text="Refresh Key List", 
            command=self.refresh_key_list
        ).grid(row=1, column=0, pady=10)
    
    def create_contacts_tab(self):
        """Create the contacts tab"""
        contacts_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(contacts_frame, text="👥 Contacts")
        
        # Configure grid
        contacts_frame.columnconfigure(0, weight=1)
        contacts_frame.rowconfigure(1, weight=1)
        
        # Top panel - Contact actions
        top_panel = ttk.Frame(contacts_frame)
        top_panel.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        top_panel.columnconfigure(2, weight=1)
        
        # Action buttons
        ttk.Button(
            top_panel, 
            text="Add Contact", 
            command=self.add_contact_dialog
        ).grid(row=0, column=0, padx=(0, 10))
        
        ttk.Button(
            top_panel, 
            text="Remove Contact", 
            command=self.remove_contact
        ).grid(row=0, column=1, padx=(0, 10))
        
        ttk.Button(
            top_panel, 
            text="Import Public Key", 
            command=self.import_contact_key
        ).grid(row=0, column=2, padx=(0, 10))
        
        # Contacts list
        list_frame = ttk.Frame(contacts_frame)
        list_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        list_frame.columnconfigure(0, weight=1)
        list_frame.rowconfigure(0, weight=1)
        
        # Treeview for contacts
        columns = ("Name", "Key ID", "IRC Nick", "Added Date")
        self.contacts_tree = ttk.Treeview(list_frame, columns=columns, show="headings", height=15)
        
        # Configure columns
        self.contacts_tree.heading("Name", text="Contact Name")
        self.contacts_tree.heading("Key ID", text="Key ID")
        self.contacts_tree.heading("IRC Nick", text="IRC Nickname")
        self.contacts_tree.heading("Added Date", text="Date Added")
        
        self.contacts_tree.column("Name", width=200)
        self.contacts_tree.column("Key ID", width=120)
        self.contacts_tree.column("IRC Nick", width=120)
        self.contacts_tree.column("Added Date", width=150)
        
        # Scrollbar for contacts
        contacts_scroll = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=self.contacts_tree.yview)
        self.contacts_tree.configure(yscrollcommand=contacts_scroll.set)
        
        self.contacts_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        contacts_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Contact info panel
        info_frame = ttk.LabelFrame(contacts_frame, text="Contact Information", padding="10")
        info_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(10, 0))
        info_frame.columnconfigure(0, weight=1)
        
        self.contact_info_text = tk.Text(info_frame, height=4, wrap=tk.WORD)
        contact_info_scroll = ttk.Scrollbar(info_frame, orient=tk.VERTICAL, command=self.contact_info_text.yview)
        self.contact_info_text.configure(yscrollcommand=contact_info_scroll.set)
        
        self.contact_info_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        contact_info_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Bind selection event
        self.contacts_tree.bind('<<TreeviewSelect>>', self.on_contact_selected)
        
        # Status
        status_frame = ttk.Frame(contacts_frame)
        status_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(5, 0))
        
        self.contact_count_var = tk.StringVar(value="Contacts: 0")
        ttk.Label(status_frame, textvariable=self.contact_count_var).pack(side=tk.LEFT)
        
        # Refresh contacts button
        ttk.Button(
            status_frame, 
            text="Refresh", 
            command=self.refresh_contacts_list
        ).pack(side=tk.RIGHT)
    
    def create_messages_tab(self):
        """Create the messages tab"""
        messages_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(messages_frame, text="💬 Messages")
        
        # Configure grid
        messages_frame.columnconfigure(0, weight=1)
        messages_frame.rowconfigure(1, weight=1)
        
        # Top panel - Message actions
        top_panel = ttk.Frame(messages_frame)
        top_panel.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        top_panel.columnconfigure(2, weight=1)
        
        # Action buttons
        ttk.Button(
            top_panel, 
            text="Compose New Message", 
            command=self.compose_message_dialog,
            style='Action.TButton'
        ).grid(row=0, column=0, padx=(0, 10))
        
        ttk.Button(
            top_panel, 
            text="Decrypt Message", 
            command=self.decrypt_message_dialog
        ).grid(row=0, column=1, padx=(0, 10))
        
        # Burn message button (prominent) - Using tkinter button for better color control
        burn_button = tk.Button(
            top_panel, 
            text="🔥 BURN MESSAGE NOW", 
            command=self.burn_message_now,
            bg='#dc3545',  # Red background
            fg='white',    # White text
            font=('Arial', 10, 'bold'),
            relief='flat',
            borderwidth=0,
            padx=15,
            pady=8,
            activebackground='#c82333',  # Darker red when clicked
            activeforeground='white'
        )
        burn_button.grid(row=0, column=3, padx=(10, 0))
        
        # Main message area
        main_panel = ttk.Frame(messages_frame)
        main_panel.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        main_panel.columnconfigure(0, weight=1)
        main_panel.rowconfigure(0, weight=1)
        
        # Notebook for message types
        self.message_notebook = ttk.Notebook(main_panel)
        self.message_notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Create message sub-tabs
        self.create_compose_tab()
        self.create_decrypt_tab()
        self.create_history_tab()
    
    def create_compose_tab(self):
        """Create the compose message tab"""
        compose_frame = ttk.Frame(self.message_notebook, padding="10")
        self.message_notebook.add(compose_frame, text="Compose")
        
        # Configure grid
        compose_frame.columnconfigure(1, weight=1)
        compose_frame.rowconfigure(2, weight=1)
        
        # Recipient selection
        ttk.Label(compose_frame, text="Recipient:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.recipient_var = tk.StringVar()
        self.recipient_combo = ttk.Combobox(
            compose_frame, 
            textvariable=self.recipient_var,
            state="readonly"
        )
        self.recipient_combo.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Subject
        ttk.Label(compose_frame, text="Subject:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.subject_var = tk.StringVar()
        ttk.Entry(
            compose_frame, 
            textvariable=self.subject_var
        ).grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Message text
        ttk.Label(compose_frame, text="Message:").grid(row=2, column=0, sticky=(tk.W, tk.N), pady=5)
        
        message_frame = ttk.Frame(compose_frame)
        message_frame.grid(row=2, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5, padx=(10, 0))
        message_frame.columnconfigure(0, weight=1)
        message_frame.rowconfigure(0, weight=1)
        
        self.compose_text = tk.Text(message_frame, wrap=tk.WORD, height=15)
        compose_scroll = ttk.Scrollbar(message_frame, orient="vertical", command=self.compose_text.yview)
        self.compose_text.configure(yscrollcommand=compose_scroll.set)
        
        self.compose_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        compose_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Encrypt button - Using tkinter button for better color control
        encrypt_button = tk.Button(
            compose_frame, 
            text="Encrypt Message", 
            command=self.encrypt_message,
            bg='#28a745',  # Green background
            fg='white',    # White text
            font=('Arial', 10, 'bold'),
            relief='flat',
            borderwidth=0,
            padx=15,
            pady=8,
            activebackground='#218838',  # Darker green when clicked
            activeforeground='white'
        )
        encrypt_button.grid(row=3, column=1, sticky=tk.E, pady=10)
    
    def create_decrypt_tab(self):
        """Create the decrypt message tab"""
        decrypt_frame = ttk.Frame(self.message_notebook, padding="10")
        self.message_notebook.add(decrypt_frame, text="Decrypt")
        
        # Configure grid
        decrypt_frame.columnconfigure(0, weight=1)
        decrypt_frame.rowconfigure(1, weight=1)
        decrypt_frame.rowconfigure(5, weight=1)
        
        # Encrypted message input
        ttk.Label(decrypt_frame, text="Encrypted Message:").grid(row=0, column=0, sticky=tk.W, pady=5)
        
        encrypted_frame = ttk.Frame(decrypt_frame)
        encrypted_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        encrypted_frame.columnconfigure(0, weight=1)
        encrypted_frame.rowconfigure(0, weight=1)
        
        self.encrypted_text = tk.Text(encrypted_frame, wrap=tk.WORD, height=8)
        encrypted_scroll = ttk.Scrollbar(encrypted_frame, orient="vertical", command=self.encrypted_text.yview)
        self.encrypted_text.configure(yscrollcommand=encrypted_scroll.set)
        
        self.encrypted_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        encrypted_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Copy and Paste buttons for encrypted text
        button_frame = ttk.Frame(decrypt_frame)
        button_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Button(
            button_frame,
            text="Paste Encrypted Message",
            command=self.paste_encrypted_message
        ).pack(side=tk.LEFT)
        
        ttk.Button(
            button_frame,
            text="Copy Encrypted Message",
            command=self.copy_encrypted_message
        ).pack(side=tk.RIGHT)
        
        # Decrypt button
        ttk.Button(
            decrypt_frame, 
            text="Decrypt Message", 
            command=self.decrypt_message,
            style='Action.TButton'
        ).grid(row=3, column=0, pady=10)
        
        # Decrypted message output
        ttk.Label(decrypt_frame, text="Decrypted Message:").grid(row=4, column=0, sticky=tk.W, pady=5)
        
        decrypted_frame = ttk.Frame(decrypt_frame)
        decrypted_frame.grid(row=5, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        decrypted_frame.columnconfigure(0, weight=1)
        decrypted_frame.rowconfigure(0, weight=1)
        
        self.decrypted_text = tk.Text(decrypted_frame, wrap=tk.WORD, height=8)
        decrypted_scroll = ttk.Scrollbar(decrypted_frame, orient="vertical", command=self.decrypted_text.yview)
        self.decrypted_text.configure(yscrollcommand=decrypted_scroll.set)
        
        self.decrypted_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        decrypted_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
    
    def create_history_tab(self):
        """Create the enhanced message history tab"""
        history_frame = ttk.Frame(self.message_notebook, padding="10")
        self.message_notebook.add(history_frame, text="History")
        
        # Configure grid
        history_frame.columnconfigure(0, weight=1)
        history_frame.rowconfigure(0, weight=1)
        
        # Create main paned window for history list and message viewer
        history_paned = ttk.PanedWindow(history_frame, orient=tk.VERTICAL)
        history_paned.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Top frame for history list
        history_list_frame = ttk.Frame(history_paned)
        history_paned.add(history_list_frame, weight=1)
        
        # Configure grid for list frame
        history_list_frame.columnconfigure(0, weight=1)
        history_list_frame.rowconfigure(1, weight=1)
        
        # History list label
        ttk.Label(history_list_frame, text="Message History", font=('Arial', 12, 'bold')).grid(
            row=0, column=0, sticky=tk.W, pady=(0, 5)
        )
        
        # Message history list
        self.history_tree = ttk.Treeview(
            history_list_frame,
            columns=('Type', 'Subject', 'Recipient', 'Date', 'ID'),
            show='tree headings'
        )
        
        # Configure columns
        self.history_tree.heading('#0', text='')
        self.history_tree.heading('Type', text='Type')
        self.history_tree.heading('Subject', text='Subject')
        self.history_tree.heading('Recipient', text='Recipient/Sender')
        self.history_tree.heading('Date', text='Date')
        self.history_tree.heading('ID', text='')  # Hidden column for message ID
        
        self.history_tree.column('#0', width=30)
        self.history_tree.column('Type', width=80)
        self.history_tree.column('Subject', width=200)
        self.history_tree.column('Recipient', width=200)
        self.history_tree.column('Date', width=120)
        self.history_tree.column('ID', width=0, stretch=False)  # Hidden
        
        # Bind selection event
        self.history_tree.bind('<<TreeviewSelect>>', self.on_history_selected)
        self.history_tree.bind('<Double-1>', self.on_history_double_click)
        
        # Scrollbars for history list
        history_v_scroll = ttk.Scrollbar(history_list_frame, orient="vertical", command=self.history_tree.yview)
        history_h_scroll = ttk.Scrollbar(history_list_frame, orient="horizontal", command=self.history_tree.xview)
        self.history_tree.configure(yscrollcommand=history_v_scroll.set, xscrollcommand=history_h_scroll.set)
        
        # Grid history list
        self.history_tree.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        history_v_scroll.grid(row=1, column=1, sticky=(tk.N, tk.S))
        history_h_scroll.grid(row=2, column=0, sticky=(tk.W, tk.E))
        
        # Bottom frame for message viewer
        message_viewer_frame = ttk.Frame(history_paned)
        history_paned.add(message_viewer_frame, weight=1)
        
        # Configure grid for viewer frame
        message_viewer_frame.columnconfigure(0, weight=1)
        message_viewer_frame.rowconfigure(1, weight=1)
        
        # Message viewer label
        self.history_message_label = ttk.Label(
            message_viewer_frame, 
            text="Select a message from the history to view its content", 
            font=('Arial', 12, 'bold')
        )
        self.history_message_label.grid(row=0, column=0, sticky=tk.W, pady=(0, 5))
        
        # Message content viewer
        self.history_message_text = tk.Text(
            message_viewer_frame,
            wrap=tk.WORD,
            font=('Consolas', 10),
            state=tk.DISABLED,
            bg='#f8f9fa',
            relief=tk.SUNKEN,
            borderwidth=2
        )
        
        # Scrollbars for message viewer
        message_v_scroll = ttk.Scrollbar(message_viewer_frame, orient="vertical", command=self.history_message_text.yview)
        message_h_scroll = ttk.Scrollbar(message_viewer_frame, orient="horizontal", command=self.history_message_text.xview)
        self.history_message_text.configure(yscrollcommand=message_v_scroll.set, xscrollcommand=message_h_scroll.set)
        
        # Grid message viewer
        self.history_message_text.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        message_v_scroll.grid(row=1, column=1, sticky=(tk.N, tk.S))
        message_h_scroll.grid(row=2, column=0, sticky=(tk.W, tk.E))
        
        # Initialize message storage
        self.message_history_data = {}
    
    def create_chat_tab(self):
        """Create the secure chat tab"""
        if not SECURE_CHAT_AVAILABLE:
            print("Secure chat not available - cannot create chat tab")
            return
            
        chat_frame = ttk.Frame(self.notebook, padding="10")
        self.notebook.add(chat_frame, text="💬 Chat")
        
        # Configure grid
        chat_frame.columnconfigure(1, weight=1)
        chat_frame.rowconfigure(0, weight=1)
        
        # Left panel - Chat controls
        left_panel = ttk.LabelFrame(chat_frame, text="Chat Controls", padding="10")
        left_panel.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        left_panel.columnconfigure(0, weight=1)
        
        # IRC Connection section
        irc_frame = ttk.LabelFrame(left_panel, text="IRC Connection", padding="5")
        irc_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        irc_frame.columnconfigure(1, weight=1)
        
        # Network selection
        ttk.Label(irc_frame, text="Network:").grid(row=0, column=0, sticky=tk.W, pady=2)
        self.chat_network_var = tk.StringVar(value="libera")
        network_combo = ttk.Combobox(irc_frame, textvariable=self.chat_network_var, 
                                   values=["libera", "oftc", "efnet"], state="readonly", width=15)
        network_combo.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(5, 0), pady=2)
        
        # Nickname
        ttk.Label(irc_frame, text="Nickname:").grid(row=1, column=0, sticky=tk.W, pady=2)
        self.chat_nickname_var = tk.StringVar()
        nickname_entry = ttk.Entry(irc_frame, textvariable=self.chat_nickname_var, width=15)
        nickname_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), padx=(5, 0), pady=2)
        
        # Generate random nickname button
        ttk.Button(irc_frame, text="Random", command=self.generate_chat_nickname, 
                  width=8).grid(row=2, column=0, pady=5)
        
        # Connect/Disconnect button
        self.chat_connect_button = ttk.Button(irc_frame, text="Connect", 
                                            command=self.toggle_chat_connection, width=12)
        self.chat_connect_button.grid(row=2, column=1, pady=5, padx=(5, 0))
        
        # Connection status
        self.chat_status_var = tk.StringVar(value="Disconnected")
        self.chat_status_label = ttk.Label(irc_frame, textvariable=self.chat_status_var, 
                                         foreground="red", font=('Arial', 9))
        self.chat_status_label.grid(row=3, column=0, columnspan=2, pady=2)
        
        # Chat Contacts section
        contacts_frame = ttk.LabelFrame(left_panel, text="Chat Contacts", padding="5")
        contacts_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        contacts_frame.columnconfigure(0, weight=1)
        contacts_frame.rowconfigure(1, weight=1)
        
        # Add contact button
        ttk.Button(contacts_frame, text="Add Contact", 
                  command=self.add_chat_contact_dialog, width=15).grid(row=0, column=0, pady=(0, 5))
        
        # Contacts list
        self.chat_contacts_listbox = tk.Listbox(contacts_frame, height=8)
        self.chat_contacts_listbox.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.chat_contacts_listbox.bind('<Double-Button-1>', self.start_chat_with_contact)
        
        # Chat controls
        chat_controls_frame = ttk.LabelFrame(left_panel, text="Chat Settings", padding="5")
        chat_controls_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        # Save history checkbox
        self.chat_save_history_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(chat_controls_frame, text="Save chat history", 
                       variable=self.chat_save_history_var).grid(row=0, column=0, sticky=tk.W)
        
        # Right panel - Chat interface with tabs
        right_panel = ttk.LabelFrame(chat_frame, text="Secure Chat", padding="10")
        right_panel.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        right_panel.columnconfigure(0, weight=1)
        right_panel.rowconfigure(0, weight=1)
        
        # Create notebook for private and group chat
        self.chat_notebook = ttk.Notebook(right_panel)
        self.chat_notebook.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Private Chat Tab
        private_chat_frame = ttk.Frame(self.chat_notebook, padding="10")
        self.chat_notebook.add(private_chat_frame, text="💬 Private Chat")
        private_chat_frame.columnconfigure(0, weight=1)
        private_chat_frame.rowconfigure(1, weight=1)
        
        # Chat target selection
        target_frame = ttk.Frame(private_chat_frame)
        target_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        target_frame.columnconfigure(1, weight=1)
        
        ttk.Label(target_frame, text="Chat with:").grid(row=0, column=0, sticky=tk.W)
        self.chat_target_var = tk.StringVar()
        self.chat_target_combo = ttk.Combobox(target_frame, textvariable=self.chat_target_var, 
                                            state="readonly", width=20)
        self.chat_target_combo.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(5, 0))
        
        # Chat log
        chat_log_frame = ttk.Frame(private_chat_frame)
        chat_log_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        chat_log_frame.columnconfigure(0, weight=1)
        chat_log_frame.rowconfigure(0, weight=1)
        
        self.chat_log_text = tk.Text(chat_log_frame, height=15, wrap=tk.WORD, state=tk.DISABLED)
        self.chat_log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Chat log scrollbar
        chat_scroll = ttk.Scrollbar(chat_log_frame, orient="vertical", command=self.chat_log_text.yview)
        chat_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.chat_log_text.configure(yscrollcommand=chat_scroll.set)
        
        # Message input
        input_frame = ttk.Frame(private_chat_frame)
        input_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(10, 0))
        input_frame.columnconfigure(0, weight=1)
        
        self.chat_message_var = tk.StringVar()
        self.chat_message_entry = ttk.Entry(input_frame, textvariable=self.chat_message_var)
        self.chat_message_entry.grid(row=0, column=0, sticky=(tk.W, tk.E), padx=(0, 5))
        self.chat_message_entry.bind('<Return>', self.send_chat_message)
        
        self.chat_send_button = ttk.Button(input_frame, text="Send Encrypted", 
                                         command=self.send_chat_message, state="disabled")
        self.chat_send_button.grid(row=0, column=1)
        
        # Group Chat Tab
        self.create_group_chat_tab()
        
        # Initialize chat system
        self.secure_chat = None
        self.group_chat = None
        self.chat_contacts = {}  # nickname -> contact info
        
        # Generate initial nickname
        self.generate_chat_nickname()
    
    def create_group_chat_tab(self):
        """Create the group chat tab"""
        group_chat_frame = ttk.Frame(self.chat_notebook, padding="10")
        self.chat_notebook.add(group_chat_frame, text="👥 Group Chat")
        group_chat_frame.columnconfigure(1, weight=1)
        group_chat_frame.rowconfigure(1, weight=1)
        
        # Left panel - Group management
        group_left_panel = ttk.LabelFrame(group_chat_frame, text="Groups", padding="5")
        group_left_panel.grid(row=0, column=0, rowspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        group_left_panel.columnconfigure(0, weight=1)
        group_left_panel.rowconfigure(2, weight=1)
        
        # Group controls
        group_controls_frame = ttk.Frame(group_left_panel)
        group_controls_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        group_controls_frame.columnconfigure(0, weight=1)
        
        ttk.Button(group_controls_frame, text="Create Group", 
                  command=self.create_group_dialog, width=15).grid(row=0, column=0, pady=2)
        ttk.Button(group_controls_frame, text="Join Group", 
                  command=self.join_group_dialog, width=15).grid(row=1, column=0, pady=2)
        ttk.Button(group_controls_frame, text="Leave Group", 
                  command=self.leave_current_group, width=15).grid(row=2, column=0, pady=2)
        
        # Current group info
        current_group_frame = ttk.LabelFrame(group_left_panel, text="Current Group", padding="5")
        current_group_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        current_group_frame.columnconfigure(0, weight=1)
        
        self.current_group_var = tk.StringVar(value="None")
        ttk.Label(current_group_frame, textvariable=self.current_group_var, 
                 font=('Arial', 9, 'bold')).grid(row=0, column=0, sticky=tk.W)
        
        self.group_member_count_var = tk.StringVar(value="0 members")
        ttk.Label(current_group_frame, textvariable=self.group_member_count_var).grid(row=1, column=0, sticky=tk.W)
        
        # Groups list
        groups_list_frame = ttk.LabelFrame(group_left_panel, text="My Groups", padding="5")
        groups_list_frame.grid(row=2, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        groups_list_frame.columnconfigure(0, weight=1)
        groups_list_frame.rowconfigure(0, weight=1)
        
        self.groups_listbox = tk.Listbox(groups_list_frame, height=8)
        self.groups_listbox.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.groups_listbox.bind('<Double-Button-1>', self.switch_to_group)
        self.groups_listbox.bind('<Button-3>', self.show_group_context_menu)  # Right-click
        
        # Right panel - Group chat interface
        group_right_panel = ttk.Frame(group_chat_frame)
        group_right_panel.grid(row=0, column=1, rowspan=2, sticky=(tk.W, tk.E, tk.N, tk.S))
        group_right_panel.columnconfigure(0, weight=1)
        group_right_panel.rowconfigure(1, weight=1)
        
        # Group chat header
        group_header_frame = ttk.Frame(group_right_panel)
        group_header_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        group_header_frame.columnconfigure(0, weight=1)
        
        self.group_chat_title_var = tk.StringVar(value="Select a group to start chatting")
        ttk.Label(group_header_frame, textvariable=self.group_chat_title_var, 
                 font=('Arial', 12, 'bold')).grid(row=0, column=0, sticky=tk.W)
        
        ttk.Button(group_header_frame, text="Manage Members", 
                  command=self.manage_group_members_dialog, width=15).grid(row=0, column=1)
        
        # Group chat log
        group_chat_log_frame = ttk.Frame(group_right_panel)
        group_chat_log_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        group_chat_log_frame.columnconfigure(0, weight=1)
        group_chat_log_frame.rowconfigure(0, weight=1)
        
        self.group_chat_log_text = tk.Text(group_chat_log_frame, height=15, wrap=tk.WORD, state=tk.DISABLED)
        self.group_chat_log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Group chat log scrollbar
        group_chat_scroll = ttk.Scrollbar(group_chat_log_frame, orient="vertical", command=self.group_chat_log_text.yview)
        group_chat_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        self.group_chat_log_text.configure(yscrollcommand=group_chat_scroll.set)
        
        # Group message input
        group_input_frame = ttk.Frame(group_right_panel)
        group_input_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(10, 0))
        group_input_frame.columnconfigure(0, weight=1)
        
        self.group_message_var = tk.StringVar()
        self.group_message_entry = ttk.Entry(group_input_frame, textvariable=self.group_message_var)
        self.group_message_entry.grid(row=0, column=0, sticky=(tk.W, tk.E), padx=(0, 5))
        self.group_message_entry.bind('<Return>', self.send_group_message)
        
        self.group_send_button = ttk.Button(group_input_frame, text="Send to Group", 
                                          command=self.send_group_message, state="disabled")
        self.group_send_button.grid(row=0, column=1)
    
    def create_status_bar(self, parent):
        """Create the status bar"""
        status_frame = ttk.Frame(parent)
        status_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(10, 0))
        status_frame.columnconfigure(1, weight=1)
        
        # Status label
        self.status_var = tk.StringVar()
        self.status_var.set("Ready")
        ttk.Label(status_frame, textvariable=self.status_var).grid(row=0, column=0, sticky=tk.W)
        
        # Emergency Kill Switch button (prominent)
        kill_button = tk.Button(
            status_frame, 
            text="🚨 EMERGENCY KILL", 
            command=self.emergency_kill_switch,
            bg="#dc3545",  # Red background
            fg="white",    # White text
            font=("Arial", 9, "bold"),
            relief=tk.RAISED,
            bd=2,
            padx=10,
            pady=2
        )
        kill_button.grid(row=0, column=1, padx=10)
        
        # Key count label
        self.key_count_var = tk.StringVar()
        self.key_count_var.set("Keys: 0")
        ttk.Label(status_frame, textvariable=self.key_count_var).grid(row=0, column=2, sticky=tk.E)
    
    # Event handlers and dialog methods
    def generate_key_dialog(self):
        """Show key generation dialog"""
        from .dialogs import KeyGenerationDialog
        
        dialog = KeyGenerationDialog(self.root, self.key_generator)
        result = dialog.show()
        
        if result and result['success']:
            self.refresh_key_list()
            self.status_var.set("New key pair generated successfully")
    
    def import_key_dialog(self):
        """Show import key dialog"""
        from .dialogs import ImportKeyDialog
        
        dialog = ImportKeyDialog(self.root, self.key_generator)
        result = dialog.show()
        
        if result and result['success']:
            self.refresh_key_list()
            self.status_var.set(f"Imported {result['imported_count']} key(s)")
    
    def export_keys_dialog(self):
        """Show export keys dialog"""
        # Get all keys
        public_keys = self.key_generator.list_keys(secret=False)
        private_keys = self.key_generator.list_keys(secret=True)
        
        if not public_keys and not private_keys:
            messagebox.showinfo("Info", "No keys available to export")
            return
        
        # Ask user what to export
        export_choice = messagebox.askyesnocancel(
            "Export Keys",
            "What would you like to export?\n\n"
            "Yes = All Public Keys\n"
            "No = All Private Keys\n"
            "Cancel = Selected Key Only"
        )
        
        if export_choice is None:  # Cancel - export selected key
            self.export_selected_key()
            return
        
        # Choose file location
        filename = filedialog.asksaveasfilename(
            title="Save Keys As",
            defaultextension=".asc",
            filetypes=[
                ("ASCII Armor", "*.asc"),
                ("PGP Key", "*.pgp"),
                ("Text File", "*.txt"),
                ("All Files", "*.*")
            ]
        )
        
        if not filename:
            return
        
        try:
            if export_choice:  # Export public keys
                keys_data = ""
                for key in public_keys:
                    result = self.key_generator.export_public_key(key['fingerprint'])
                    if result['success']:
                        keys_data += result['public_key'] + "\n\n"
                
                if keys_data:
                    with open(filename, 'w') as f:
                        f.write(keys_data)
                    messagebox.showinfo("Success", f"Exported {len(public_keys)} public key(s)")
                else:
                    messagebox.showerror("Error", "No keys could be exported")
            
            else:  # Export private keys
                passphrase = self.get_passphrase("Enter passphrase for private key export:")
                if not passphrase:
                    return
                
                keys_data = ""
                exported_count = 0
                
                for key in private_keys:
                    result = self.key_generator.export_private_key(key['fingerprint'], passphrase)
                    if result['success']:
                        keys_data += result['private_key'] + "\n\n"
                        exported_count += 1
                
                if keys_data:
                    with open(filename, 'w') as f:
                        f.write(keys_data)
                    messagebox.showinfo("Success", f"Exported {exported_count} private key(s)")
                else:
                    messagebox.showerror("Error", "No private keys could be exported")
        
        except Exception as e:
            messagebox.showerror("Error", f"Export failed: {str(e)}")
    
    def export_selected_key(self):
        """Export the selected key"""
        selection = self.key_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a key to export")
            return
        
        # Get selected key info
        item = self.key_tree.item(selection[0])
        values = item['values']
        key_type = values[0]  # Public or Private
        key_id = values[3]    # Key ID
        
        # Find the full key info
        if key_type == "Public":
            keys = self.key_generator.list_keys(secret=False)
        else:
            keys = self.key_generator.list_keys(secret=True)
        
        selected_key = None
        for key in keys:
            if key['keyid'].endswith(key_id):
                selected_key = key
                break
        
        if not selected_key:
            messagebox.showerror("Error", "Could not find selected key")
            return
        
        # Choose file location
        filename = filedialog.asksaveasfilename(
            title="Export Key As",
            defaultextension=".asc",
            filetypes=[
                ("ASCII Armor", "*.asc"),
                ("PGP Key", "*.pgp"),
                ("Text File", "*.txt"),
                ("All Files", "*.*")
            ]
        )
        
        if not filename:
            return
        
        try:
            if key_type == "Public":
                result = self.key_generator.export_public_key(selected_key['fingerprint'])
                if result['success']:
                    with open(filename, 'w') as f:
                        f.write(result['public_key'])
                    messagebox.showinfo("Success", "Public key exported successfully")
                else:
                    messagebox.showerror("Error", f"Export failed: {result['error']}")
            
            else:  # Private key
                passphrase = self.get_passphrase("Enter passphrase for private key:")
                if not passphrase:
                    return
                
                result = self.key_generator.export_private_key(selected_key['fingerprint'], passphrase)
                if result['success']:
                    with open(filename, 'w') as f:
                        f.write(result['private_key'])
                    messagebox.showinfo("Success", "Private key exported successfully")
                else:
                    messagebox.showerror("Error", f"Export failed: {result['error']}")
        
        except Exception as e:
            messagebox.showerror("Error", f"Export failed: {str(e)}")
    
    def delete_selected_key(self):
        """Delete the selected key"""
        selection = self.key_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a key to delete")
            return
        
        # Get selected key info
        item = self.key_tree.item(selection[0])
        values = item['values']
        key_type = values[0]  # Public or Private
        key_name = values[1]  # Name
        key_id = values[3]    # Key ID
        
        # Confirm deletion
        if not messagebox.askyesno(
            "Confirm Deletion",
            f"Are you sure you want to delete this {key_type.lower()} key?\n\n"
            f"Name: {key_name}\n"
            f"Key ID: {key_id}\n\n"
            "This action cannot be undone!"
        ):
            return
        
        # Find the full key info
        if key_type == "Public":
            keys = self.key_generator.list_keys(secret=False)
        else:
            keys = self.key_generator.list_keys(secret=True)
        
        selected_key = None
        for key in keys:
            if key['keyid'].endswith(key_id):
                selected_key = key
                break
        
        if not selected_key:
            messagebox.showerror("Error", "Could not find selected key")
            return
        
        try:
            if key_type == "Private":
                passphrase = self.get_passphrase("Enter passphrase to delete private key:")
                if not passphrase:
                    return
                
                # Note: Passphrase verification could be added here if needed
                # For now, we'll proceed with deletion without passphrase verification
                result = self.key_generator.delete_key(
                    selected_key['fingerprint'], 
                    secret=True
                )
            else:
                result = self.key_generator.delete_key(selected_key['fingerprint'], secret=False)
            
            if result['success']:
                self.refresh_key_list()
                self.status_var.set(f"{key_type} key deleted successfully")
            else:
                messagebox.showerror("Error", f"Deletion failed: {result['error']}")
        
        except Exception as e:
            messagebox.showerror("Error", f"Deletion failed: {str(e)}")
    
    def get_passphrase(self, prompt):
        """Get passphrase from user"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Passphrase Required")
        dialog.geometry("400x150")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Content
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(main_frame, text=prompt).pack(pady=(0, 10))
        
        passphrase_var = tk.StringVar()
        entry = ttk.Entry(main_frame, textvariable=passphrase_var, show="*", width=40)
        entry.pack(pady=(0, 20))
        entry.focus()
        
        result = [None]  # Use list to allow modification in nested function
        
        def ok_clicked():
            result[0] = passphrase_var.get()
            dialog.destroy()
        
        def cancel_clicked():
            dialog.destroy()
        
        button_frame = ttk.Frame(main_frame)
        button_frame.pack()
        
        ttk.Button(button_frame, text="OK", command=ok_clicked).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=cancel_clicked).pack(side=tk.LEFT)
        
        # Bind Enter key
        entry.bind('<Return>', lambda e: ok_clicked())
        
        dialog.wait_window()
        return result[0]
    
    def create_backup_dialog(self):
        """Show create backup dialog"""
        # Check if there are any keys to backup
        public_keys = self.key_generator.list_keys(secret=False)
        private_keys = self.key_generator.list_keys(secret=True)
        
        if not public_keys and not private_keys:
            messagebox.showinfo("Info", "No keys available to backup")
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Create Encrypted Backup")
        dialog.geometry("500x400")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Content
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        ttk.Label(main_frame, text="Create Encrypted Backup", font=('Arial', 16, 'bold')).pack(pady=(0, 20))
        
        # Instructions
        instructions = tk.Text(main_frame, height=4, wrap=tk.WORD)
        instructions.pack(fill=tk.X, pady=(0, 20))
        instructions.insert(tk.END, 
            "This will create an encrypted backup of all your keys. "
            "The backup will be protected with a password you choose. "
            "Keep this backup file and password safe - you'll need both to restore your keys."
        )
        instructions.config(state=tk.DISABLED)
        
        # Key passphrase
        ttk.Label(main_frame, text="Enter your key passphrase (for private keys):").pack(anchor=tk.W, pady=5)
        key_passphrase_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=key_passphrase_var, show="*", width=50).pack(fill=tk.X, pady=(0, 10))
        
        # Backup password
        ttk.Label(main_frame, text="Choose backup password:").pack(anchor=tk.W, pady=5)
        backup_password_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=backup_password_var, show="*", width=50).pack(fill=tk.X, pady=(0, 10))
        
        # Confirm backup password
        ttk.Label(main_frame, text="Confirm backup password:").pack(anchor=tk.W, pady=5)
        confirm_password_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=confirm_password_var, show="*", width=50).pack(fill=tk.X, pady=(0, 20))
        
        def create_backup():
            key_passphrase = key_passphrase_var.get()
            backup_password = backup_password_var.get()
            confirm_password = confirm_password_var.get()
            
            if not backup_password:
                messagebox.showerror("Error", "Please enter a backup password")
                return
            
            if backup_password != confirm_password:
                messagebox.showerror("Error", "Backup passwords do not match")
                return
            
            if len(backup_password) < 8:
                messagebox.showerror("Error", "Backup password must be at least 8 characters long")
                return
            
            # Choose save location
            filename = filedialog.asksaveasfilename(
                title="Save Backup As",
                defaultextension=".pgpbackup",
                filetypes=[
                    ("PGP Backup", "*.pgpbackup"),
                    ("Encrypted File", "*.enc"),
                    ("All Files", "*.*")
                ]
            )
            
            if not filename:
                return
            
            try:
                result = self.key_generator.create_backup(backup_password, key_passphrase)
                
                if result['success']:
                    with open(filename, 'w') as f:
                        f.write(result['encrypted_backup'])
                    
                    messagebox.showinfo("Success", f"Backup created successfully!\n\nFile: {filename}")
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", f"Backup creation failed: {result['error']}")
            
            except Exception as e:
                messagebox.showerror("Error", f"Backup creation failed: {str(e)}")
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X)
        
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.RIGHT)
        ttk.Button(button_frame, text="Create Backup", command=create_backup).pack(side=tk.RIGHT, padx=(0, 10))
    
    def restore_backup_dialog(self):
        """Show restore backup dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Restore from Backup")
        dialog.geometry("500x400")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Content
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        ttk.Label(main_frame, text="Restore from Backup", font=('Arial', 16, 'bold')).pack(pady=(0, 20))
        
        # Instructions
        instructions = tk.Text(main_frame, height=3, wrap=tk.WORD)
        instructions.pack(fill=tk.X, pady=(0, 20))
        instructions.insert(tk.END, 
            "Select your backup file and enter the backup password to restore your keys. "
            "This will import all keys from the backup into your current keyring."
        )
        instructions.config(state=tk.DISABLED)
        
        # File selection
        file_frame = ttk.Frame(main_frame)
        file_frame.pack(fill=tk.X, pady=(0, 20))
        
        ttk.Label(file_frame, text="Backup file:").pack(anchor=tk.W)
        
        file_select_frame = ttk.Frame(file_frame)
        file_select_frame.pack(fill=tk.X, pady=5)
        
        backup_file_var = tk.StringVar()
        file_entry = ttk.Entry(file_select_frame, textvariable=backup_file_var, width=50)
        file_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        def browse_file():
            filename = filedialog.askopenfilename(
                title="Select Backup File",
                filetypes=[
                    ("PGP Backup", "*.pgpbackup"),
                    ("Encrypted File", "*.enc"),
                    ("All Files", "*.*")
                ]
            )
            if filename:
                backup_file_var.set(filename)
        
        ttk.Button(file_select_frame, text="Browse", command=browse_file).pack(side=tk.RIGHT, padx=(10, 0))
        
        # Backup password
        ttk.Label(main_frame, text="Backup password:").pack(anchor=tk.W, pady=5)
        backup_password_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=backup_password_var, show="*", width=50).pack(fill=tk.X, pady=(0, 20))
        
        def restore_backup():
            backup_file = backup_file_var.get()
            backup_password = backup_password_var.get()
            
            if not backup_file:
                messagebox.showerror("Error", "Please select a backup file")
                return
            
            if not backup_password:
                messagebox.showerror("Error", "Please enter the backup password")
                return
            
            try:
                # Read backup file
                with open(backup_file, 'r') as f:
                    encrypted_backup = f.read()
                
                # Restore backup
                result = self.key_generator.restore_backup(encrypted_backup, backup_password)
                
                if result['success']:
                    messagebox.showinfo("Success", "Backup restored successfully!")
                    self.refresh_key_list()
                    dialog.destroy()
                else:
                    messagebox.showerror("Error", f"Backup restore failed: {result['error']}")
            
            except FileNotFoundError:
                messagebox.showerror("Error", "Backup file not found")
            except Exception as e:
                messagebox.showerror("Error", f"Backup restore failed: {str(e)}")
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X)
        
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.RIGHT)
        ttk.Button(button_frame, text="Restore Backup", command=restore_backup).pack(side=tk.RIGHT, padx=(0, 10))
    
    def emergency_kill_switch(self):
        """Emergency data deletion"""
        result = messagebox.askyesno(
            "EMERGENCY KILL SWITCH", 
            "⚠️ WARNING ⚠️\n\n"
            "This will PERMANENTLY DELETE ALL:\n"
            "• Private keys\n"
            "• Public keys\n"
            "• Messages\n"
            "• Application data\n\n"
            "This action CANNOT be undone!\n\n"
            "Are you absolutely sure?"
        )
        if result:
            # Confirm again
            confirm = messagebox.askyesno(
                "FINAL CONFIRMATION", 
                "Last chance to cancel!\n\n"
                "Delete ALL data permanently?\n\n"
                "Type 'DELETE' to confirm:",
                icon='warning'
            )
            if confirm:
                # Get final confirmation by typing
                confirm_text = self.get_text_confirmation("Type 'DELETE' to confirm permanent data deletion:")
                if confirm_text == "DELETE":
                    self.perform_emergency_deletion()
                else:
                    messagebox.showinfo("Cancelled", "Emergency deletion cancelled")
    
    def get_text_confirmation(self, prompt):
        """Get text confirmation from user"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Confirmation Required")
        dialog.geometry("400x150")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Content
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(main_frame, text=prompt).pack(pady=(0, 10))
        
        text_var = tk.StringVar()
        entry = ttk.Entry(main_frame, textvariable=text_var, width=40)
        entry.pack(pady=(0, 20))
        entry.focus()
        
        result = [None]
        
        def ok_clicked():
            result[0] = text_var.get()
            dialog.destroy()
        
        def cancel_clicked():
            dialog.destroy()
        
        button_frame = ttk.Frame(main_frame)
        button_frame.pack()
        
        ttk.Button(button_frame, text="OK", command=ok_clicked).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=cancel_clicked).pack(side=tk.LEFT)
        
        entry.bind('<Return>', lambda e: ok_clicked())
        
        dialog.wait_window()
        return result[0] or ""
    
    def perform_emergency_deletion(self):
        """Perform the actual emergency deletion"""
        try:
            # Clear all GUI fields
            self.compose_text.delete(1.0, tk.END)
            self.encrypted_text.delete(1.0, tk.END)
            self.decrypted_text.config(state=tk.NORMAL)
            self.decrypted_text.delete(1.0, tk.END)
            self.decrypted_text.config(state=tk.DISABLED)
            self.subject_var.set("")
            self.key_info_text.delete(1.0, tk.END)
            
            # Clear key tree
            for item in self.key_tree.get_children():
                self.key_tree.delete(item)
            
            # Clear history tree
            for item in self.history_tree.get_children():
                self.history_tree.delete(item)
            
            # Clear clipboard
            try:
                self.root.clipboard_clear()
            except:
                pass
            
            # Delete all keys
            public_keys = self.key_generator.list_keys(secret=False)
            private_keys = self.key_generator.list_keys(secret=True)
            
            for key in private_keys:
                try:
                    self.key_generator.delete_key(key['fingerprint'], secret=True)
                except:
                    pass
            
            for key in public_keys:
                try:
                    self.key_generator.delete_key(key['fingerprint'], secret=False)
                except:
                    pass
            
            # Clean up crypto backend
            self.key_generator.cleanup()
            
            # Delete data directory
            import shutil
            if os.path.exists(DATA_DIR):
                try:
                    shutil.rmtree(DATA_DIR)
                except:
                    pass
            
            # Recreate data directory
            os.makedirs(DATA_DIR, exist_ok=True)
            
            # Reinitialize crypto backend
            self.key_generator = SecureKeyGenerator(
                gnupg_home=os.path.join(DATA_DIR, "gnupg")
            )
            
            # Update status
            self.status_var.set("EMERGENCY DELETION COMPLETED")
            self.key_count_var.set("Keys: 0")
            
            messagebox.showinfo(
                "Emergency Deletion Complete", 
                "All data has been permanently deleted.\n\n"
                "The application has been reset to a clean state."
            )
            
        except Exception as e:
            messagebox.showerror("Error", f"Emergency deletion encountered an error: {str(e)}")
    
    def clear_all_data(self):
        """Clear all application data"""
        result = messagebox.askyesno(
            "Clear All Data",
            "This will delete all keys, messages, and application data.\n\n"
            "Are you sure you want to continue?"
        )
        
        if result:
            confirm = messagebox.askyesno(
                "Confirm Clear Data",
                "This action cannot be undone!\n\n"
                "Proceed with clearing all data?"
            )
            
            if confirm:
                self.perform_emergency_deletion()
    
    def compose_message_dialog(self):
        """Show compose message dialog"""
        # Switch to compose tab
        self.message_notebook.select(0)
        self.notebook.select(1)  # Switch to Messages tab
        
        # Update recipient list
        self.update_recipient_list()
    
    def decrypt_message_dialog(self):
        """Show decrypt message dialog"""
        # Switch to decrypt tab
        self.message_notebook.select(1)
        self.notebook.select(1)  # Switch to Messages tab
    
    def update_recipient_list(self):
        """Update the recipient combobox with available public keys and contacts"""
        # Get all public keys
        public_keys = self.key_generator.list_keys(secret=False)
        key_map = {key['fingerprint']: key for key in public_keys}
        
        # Get contacts
        contacts = self.load_contacts()
        
        recipients = []
        
        # Add contacts first (preferred)
        for fingerprint, contact_info in contacts.items():
            if fingerprint in key_map:
                key_info = key_map[fingerprint]
                recipients.append(f"📞 {contact_info['name']} ({key_info['keyid'][-8:]})")
        
        # Add separator if we have both contacts and other keys
        if contacts and len(public_keys) > len(contacts):
            recipients.append("--- Other Public Keys ---")
        
        # Add other public keys (not in contacts)
        for key in public_keys:
            if key['fingerprint'] not in contacts:
                if key['uids']:
                    uid = key['uids'][0]
                    recipients.append(f"🔑 {uid} ({key['keyid'][-8:]})")
        
        self.recipient_combo['values'] = recipients
        
        if recipients and not recipients[0].startswith("---"):
            self.recipient_combo.set(recipients[0])
        elif len(recipients) > 1:
            # Skip separator and select first actual recipient
            for recipient in recipients:
                if not recipient.startswith("---"):
                    self.recipient_combo.set(recipient)
                    break
        else:
            self.recipient_combo.set("No public keys available")
    
    def encrypt_message(self):
        """Encrypt the composed message"""
        # Get message content
        subject = self.subject_var.get().strip()
        message_text = self.compose_text.get(1.0, tk.END).strip()
        recipient = self.recipient_var.get()
        
        if not message_text:
            messagebox.showwarning("Warning", "Please enter a message to encrypt")
            return
        
        if not recipient or recipient == "No public keys available":
            messagebox.showwarning("Warning", "Please select a recipient")
            return
        
        try:
            # Extract key ID from recipient string
            key_id = recipient.split('(')[-1].replace(')', '')
            
            # Find the full fingerprint
            public_keys = self.key_generator.list_keys(secret=False)
            recipient_fingerprint = None
            
            for key in public_keys:
                if key['keyid'].endswith(key_id):
                    recipient_fingerprint = key['fingerprint']
                    break
            
            if not recipient_fingerprint:
                messagebox.showerror("Error", "Could not find recipient key")
                return
            
            # Prepare full message
            full_message = f"Subject: {subject}\n\n{message_text}"
            
            # Encrypt the message
            result = self.key_generator.encrypt_message(full_message, [recipient_fingerprint])
            
            if result['success']:
                # Show encrypted message in a dialog
                self.show_encrypted_message(result['encrypted_message'], subject, recipient)
                
                # Clear compose fields
                self.compose_text.delete(1.0, tk.END)
                self.subject_var.set("")
                
                self.status_var.set("Message encrypted successfully")
            else:
                messagebox.showerror("Error", f"Encryption failed: {result['error']}")
        
        except Exception as e:
            messagebox.showerror("Error", f"Encryption failed: {str(e)}")
    
    def show_encrypted_message(self, encrypted_message, subject, recipient):
        """Show the encrypted message in a dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Encrypted Message")
        dialog.geometry("600x500")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Content
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        ttk.Label(main_frame, text="Message Encrypted Successfully", font=('Arial', 16, 'bold')).pack(pady=(0, 10))
        
        # Info
        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(info_frame, text=f"Subject: {subject}").pack(anchor=tk.W)
        ttk.Label(info_frame, text=f"Recipient: {recipient}").pack(anchor=tk.W)
        
        # Encrypted message
        ttk.Label(main_frame, text="Encrypted Message:").pack(anchor=tk.W, pady=(10, 5))
        
        text_frame = ttk.Frame(main_frame)
        text_frame.pack(fill=tk.BOTH, expand=True)
        
        text_widget = tk.Text(text_frame, wrap=tk.WORD)
        text_scroll = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=text_scroll.set)
        
        text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        text_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        
        text_widget.insert(tk.END, encrypted_message)
        text_widget.config(state=tk.DISABLED)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(10, 0))
        
        def copy_to_clipboard():
            dialog.clipboard_clear()
            dialog.clipboard_append(encrypted_message)
            messagebox.showinfo("Copied", "Encrypted message copied to clipboard")
        
        def save_to_file():
            filename = filedialog.asksaveasfilename(
                title="Save Encrypted Message",
                defaultextension=".txt",
                filetypes=[
                    ("Text Files", "*.txt"),
                    ("PGP Message", "*.pgp"),
                    ("All Files", "*.*")
                ]
            )
            
            if filename:
                try:
                    with open(filename, 'w') as f:
                        f.write(encrypted_message)
                    messagebox.showinfo("Saved", "Encrypted message saved to file")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to save file: {str(e)}")
        
        ttk.Button(button_frame, text="Copy to Clipboard", command=copy_to_clipboard).pack(side=tk.LEFT)
        ttk.Button(button_frame, text="Save to File", command=save_to_file).pack(side=tk.LEFT, padx=(10, 0))
        ttk.Button(button_frame, text="Close", command=dialog.destroy).pack(side=tk.RIGHT)
    
    def decrypt_message(self):
        """Decrypt the input message"""
        encrypted_message = self.encrypted_text.get(1.0, tk.END).strip()
        
        if not encrypted_message:
            messagebox.showwarning("Warning", "Please enter an encrypted message to decrypt")
            return
        
        # Validate message format
        if not ("-----BEGIN PGP MESSAGE-----" in encrypted_message and "-----END PGP MESSAGE-----" in encrypted_message):
            messagebox.showerror("Error", "Invalid PGP message format")
            return
        
        # Get passphrase
        passphrase = self.get_passphrase("Enter passphrase to decrypt message:")
        if not passphrase:
            return
        
        try:
            result = self.key_generator.decrypt_message(encrypted_message, passphrase)
            
            if result['success']:
                decrypted_message = result['decrypted_message']
                
                # Display decrypted message
                self.decrypted_text.config(state=tk.NORMAL)
                self.decrypted_text.delete(1.0, tk.END)
                self.decrypted_text.insert(tk.END, decrypted_message)
                self.decrypted_text.config(state=tk.DISABLED)
                
                self.status_var.set("Message decrypted successfully")
                
                # Add to history
                self.add_to_message_history("Decrypted", decrypted_message[:50] + "...", "Unknown", "Now")
            else:
                messagebox.showerror("Error", f"Decryption failed: {result['error']}")
        
        except Exception as e:
            messagebox.showerror("Error", f"Decryption failed: {str(e)}")
    
    def copy_encrypted_message(self):
        """Copy encrypted message to clipboard"""
        encrypted_message = self.encrypted_text.get(1.0, tk.END).strip()
        
        if not encrypted_message:
            messagebox.showwarning("Warning", "No encrypted message to copy")
            return
        
        try:
            # Copy to clipboard
            self.root.clipboard_clear()
            self.root.clipboard_append(encrypted_message)
            
            # Show success message
            messagebox.showinfo("Success", f"Copied {len(encrypted_message)} characters to clipboard")
            
            # Update status
            self.status_var.set("Encrypted message copied to clipboard")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy to clipboard: {str(e)}")
    
    def paste_encrypted_message(self):
        """Paste encrypted message from clipboard"""
        try:
            # Get clipboard content
            clipboard_content = self.root.clipboard_get()
            
            if not clipboard_content:
                messagebox.showwarning("Warning", "Clipboard is empty")
                return
            
            # Clear existing content and paste new content
            self.encrypted_text.delete(1.0, tk.END)
            self.encrypted_text.insert(tk.END, clipboard_content)
            
            # Show success message
            messagebox.showinfo("Success", f"Pasted {len(clipboard_content)} characters from clipboard")
            
            # Update status
            self.status_var.set("Encrypted message pasted from clipboard")
            
        except tk.TclError:
            messagebox.showerror("Error", "Failed to access clipboard")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to paste from clipboard: {str(e)}")
    
    def add_to_message_history(self, msg_type, subject, recipient, date, full_content=""):
        """Add a message to the history with full content storage"""
        import uuid
        
        # Generate unique ID for this message
        message_id = str(uuid.uuid4())
        
        # Store full message content
        self.message_history_data[message_id] = {
            'type': msg_type,
            'subject': subject,
            'recipient': recipient,
            'date': date,
            'content': full_content,
            'timestamp': time.time()
        }
        
        # Add to tree view (with hidden ID column)
        self.history_tree.insert('', 'end', values=(msg_type, subject, recipient, date, message_id))
        
        # Save to persistent storage if data manager is available
        try:
            if hasattr(self.key_generator, 'data_manager') and self.key_generator.data_manager.encryption:
                self.key_generator.data_manager.save_data("message_history.json", self.message_history_data)
        except Exception as e:
            print(f"Warning: Failed to save message history: {e}")
    
    def on_history_selected(self, event):
        """Handle history item selection"""
        selection = self.history_tree.selection()
        if selection:
            item = selection[0]
            values = self.history_tree.item(item, 'values')
            
            if len(values) >= 5:
                message_id = values[4]  # Hidden ID column
                
                if message_id in self.message_history_data:
                    message_data = self.message_history_data[message_id]
                    
                    # Update label
                    self.history_message_label.config(
                        text=f"📧 {message_data['type']} Message: {message_data['subject']}"
                    )
                    
                    # Display message content
                    self.history_message_text.config(state=tk.NORMAL)
                    self.history_message_text.delete(1.0, tk.END)
                    
                    # Format message display
                    display_text = f"📋 Message Details:\n"
                    display_text += "=" * 50 + "\n\n"
                    display_text += f"Type: {message_data['type']}\n"
                    display_text += f"Subject: {message_data['subject']}\n"
                    display_text += f"Recipient/Sender: {message_data['recipient']}\n"
                    display_text += f"Date: {message_data['date']}\n"
                    display_text += "\n" + "=" * 50 + "\n"
                    display_text += "📄 Message Content:\n"
                    display_text += "=" * 50 + "\n\n"
                    display_text += message_data['content']
                    
                    self.history_message_text.insert(tk.END, display_text)
                    self.history_message_text.config(state=tk.DISABLED)
                else:
                    self.show_history_placeholder()
        else:
            self.show_history_placeholder()
    
    def on_history_double_click(self, event):
        """Handle double-click on history item"""
        selection = self.history_tree.selection()
        if selection:
            item = selection[0]
            values = self.history_tree.item(item, 'values')
            
            if len(values) >= 5:
                message_id = values[4]
                
                if message_id in self.message_history_data:
                    message_data = self.message_history_data[message_id]
                    
                    # Show message in a popup window
                    self.show_message_popup(message_data)
    
    def show_message_popup(self, message_data):
        """Show message in a popup window"""
        popup = tk.Toplevel(self.root)
        popup.title(f"Message: {message_data['subject']}")
        popup.geometry("600x500")
        popup.resizable(True, True)
        
        # Make it modal
        popup.transient(self.root)
        popup.grab_set()
        
        # Center the popup
        popup.update_idletasks()
        x = (popup.winfo_screenwidth() // 2) - (600 // 2)
        y = (popup.winfo_screenheight() // 2) - (500 // 2)
        popup.geometry(f"600x500+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(popup, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Header
        header_text = f"📧 {message_data['type']} Message - {message_data['date']}"
        ttk.Label(main_frame, text=header_text, font=('Arial', 12, 'bold')).grid(
            row=0, column=0, sticky=tk.W, pady=(0, 10)
        )
        
        # Message content
        text_widget = tk.Text(
            main_frame,
            wrap=tk.WORD,
            font=('Consolas', 10),
            bg='#f8f9fa',
            relief=tk.SUNKEN,
            borderwidth=2
        )
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        # Grid
        text_widget.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=1, column=1, sticky=(tk.N, tk.S))
        
        # Insert content
        display_text = f"Subject: {message_data['subject']}\n"
        display_text += f"Recipient/Sender: {message_data['recipient']}\n"
        display_text += f"Type: {message_data['type']}\n"
        display_text += f"Date: {message_data['date']}\n"
        display_text += "\n" + "=" * 50 + "\n\n"
        display_text += message_data['content']
        
        text_widget.insert(tk.END, display_text)
        text_widget.config(state=tk.DISABLED)
        
        # Close button
        ttk.Button(
            main_frame, 
            text="Close", 
            command=popup.destroy
        ).grid(row=2, column=0, pady=(10, 0))
    
    def show_history_placeholder(self):
        """Show placeholder text in history viewer"""
        self.history_message_label.config(text="Select a message from the history to view its content")
        self.history_message_text.config(state=tk.NORMAL)
        self.history_message_text.delete(1.0, tk.END)
        self.history_message_text.insert(tk.END, 
            "📋 Message History Viewer\n\n"
            "Select a message from the list above to view its full content.\n"
            "Double-click a message to open it in a separate window.\n\n"
            "💡 Tip: All your encrypted and decrypted messages are stored here for easy reference."
        )
        self.history_message_text.config(state=tk.DISABLED)
    
    def load_message_history(self):
        """Load message history from storage"""
        try:
            if hasattr(self.key_generator, 'data_manager') and self.key_generator.data_manager.encryption:
                stored_history = self.key_generator.data_manager.load_data("message_history.json", default={})
                self.message_history_data.update(stored_history)
                
                # Populate tree view
                for message_id, message_data in stored_history.items():
                    self.history_tree.insert('', 'end', values=(
                        message_data['type'],
                        message_data['subject'],
                        message_data['recipient'],
                        message_data['date'],
                        message_id
                    ))
        except Exception as e:
            print(f"Warning: Failed to load message history: {e}")
    
    def burn_message_now(self):
        """Burn/delete the current message"""
        result = messagebox.askyesno(
            "Burn Message", 
            "Are you sure you want to permanently delete the current message?\n\nThis action cannot be undone!"
        )
        if result:
            # Clear all message fields in compose tab
            self.compose_text.delete(1.0, tk.END)
            
            # Clear encrypted message field in decrypt tab
            self.encrypted_text.delete(1.0, tk.END)
            
            # Clear decrypted message field in decrypt tab
            self.decrypted_text.config(state=tk.NORMAL)
            self.decrypted_text.delete(1.0, tk.END)
            self.decrypted_text.config(state=tk.DISABLED)
            
            # Clear history message viewer
            self.history_message_text.config(state=tk.NORMAL)
            self.history_message_text.delete(1.0, tk.END)
            self.history_message_text.config(state=tk.DISABLED)
            
            # Clear subject and recipient fields
            self.subject_var.set("")
            if hasattr(self, 'recipient_var'):
                self.recipient_var.set("")
            
            # Clear any selected history item
            for item in self.history_tree.selection():
                self.history_tree.selection_remove(item)
            
            # Update status
            self.status_var.set("Message burned successfully")
            
            # Also clear clipboard for security
            try:
                self.root.clipboard_clear()
                self.root.clipboard_append("")  # Ensure clipboard is truly cleared
            except:
                pass
            
            # Force a refresh of the display
            self.root.update_idletasks()
    
    def emergency_kill_switch(self):
        """Emergency data deletion"""
        result = messagebox.askyesno(
            "EMERGENCY KILL SWITCH", 
            "⚠️ WARNING ⚠️\n\nThis will PERMANENTLY DELETE ALL:\n• Private keys\n• Public keys\n• Messages\n• Contacts\n• Application data\n\nThis action CANNOT be undone!\n\nAre you absolutely sure?"
        )
        
        if result:
            confirm = messagebox.askyesno(
                "FINAL WARNING", 
                "Last chance to cancel!\n\nDelete ALL data permanently?"
            )
            if confirm:
                try:
                    # Clear clipboard
                    try:
                        self.root.clipboard_clear()
                    except:
                        pass
                    
                    # Delete all key files and data
                    import shutil
                    import os
                    
                    data_dir = self.key_generator.gnupg_home
                    if os.path.exists(data_dir):
                        # Secure deletion - overwrite files multiple times
                        for root, dirs, files in os.walk(data_dir):
                            for file in files:
                                file_path = os.path.join(root, file)
                                try:
                                    # Overwrite file with random data 3 times
                                    if os.path.exists(file_path):
                                        file_size = os.path.getsize(file_path)
                                        with open(file_path, 'wb') as f:
                                            for _ in range(3):
                                                f.seek(0)
                                                f.write(os.urandom(file_size))
                                                f.flush()
                                                os.fsync(f.fileno())
                                except:
                                    pass
                        
                        # Remove directory
                        shutil.rmtree(data_dir, ignore_errors=True)
                    
                    # Clear all GUI elements
                    for item in self.key_tree.get_children():
                        self.key_tree.delete(item)
                    
                    for item in self.contacts_tree.get_children():
                        self.contacts_tree.delete(item)
                    
                    for item in self.history_tree.get_children():
                        self.history_tree.delete(item)
                    
                    # Clear text fields
                    self.compose_text.delete(1.0, tk.END)
                    self.encrypted_text.delete(1.0, tk.END)
                    self.key_info_text.delete(1.0, tk.END)
                    self.contact_info_text.delete(1.0, tk.END)
                    
                    # Reset variables
                    self.subject_var.set("")
                    self.recipient_var.set("")
                    self.key_count_var.set("Keys: 0")
                    self.contact_count_var.set("Contacts: 0")
                    
                    # Clear recipient combo
                    self.recipient_combo['values'] = []
                    self.recipient_combo.set("No public keys available")
                    
                    messagebox.showinfo(
                        "EMERGENCY KILL COMPLETE", 
                        "All data has been permanently deleted.\n\n"
                        "The application will now exit for security."
                    )
                    
                    # Exit application
                    self.root.quit()
                    self.root.destroy()
                    
                except Exception as e:
                    messagebox.showerror("Error", f"Emergency deletion encountered an error: {str(e)}")
    
    def clear_all_data(self):
        """Clear all application data"""
        result = messagebox.askyesno(
            "Clear All Data",
            "This will delete all keys, messages, contacts, and application data.\n\n"
            "This is less secure than the Emergency Kill Switch but allows you to continue using the application.\n\n"
            "Are you sure you want to continue?"
        )
        
        if result:
            try:
                # Clear clipboard
                try:
                    self.root.clipboard_clear()
                except:
                    pass
                
                # Delete all key files and data
                import shutil
                import os
                
                data_dir = self.key_generator.gnupg_home
                if os.path.exists(data_dir):
                    # Simple deletion (not secure overwrite)
                    shutil.rmtree(data_dir, ignore_errors=True)
                    
                    # Recreate the directory
                    os.makedirs(data_dir, exist_ok=True)
                
                # Reinitialize key generator
                from crypto.key_generator import SecureKeyGenerator
                self.key_generator = SecureKeyGenerator(data_dir)
                
                # Clear all GUI elements
                for item in self.key_tree.get_children():
                    self.key_tree.delete(item)
                
                for item in self.contacts_tree.get_children():
                    self.contacts_tree.delete(item)
                
                for item in self.history_tree.get_children():
                    self.history_tree.delete(item)
                
                # Clear text fields
                self.compose_text.delete(1.0, tk.END)
                self.encrypted_text.delete(1.0, tk.END)
                self.key_info_text.delete(1.0, tk.END)
                self.contact_info_text.delete(1.0, tk.END)
                
                # Reset variables
                self.subject_var.set("")
                self.recipient_var.set("")
                self.key_count_var.set("Keys: 0")
                self.contact_count_var.set("Contacts: 0")
                
                # Clear recipient combo
                self.recipient_combo['values'] = []
                self.recipient_combo.set("No public keys available")
                
                messagebox.showinfo(
                    "Data Cleared", 
                    "All application data has been cleared.\n\n"
                    "You can now start fresh with new keys and contacts."
                )
                
                self.status_var.set("All data cleared - ready for fresh start")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to clear data: {str(e)}")
    
    def on_key_selected(self, event):
        """Handle key selection in the tree"""
        selection = self.key_tree.selection()
        if selection:
            # Get selected item
            item = selection[0]
            key_values = self.key_tree.item(item, 'values')
            if len(key_values) < 4:
                return
                
            key_type = key_values[0]  # Type (Public/Private)
            key_name = key_values[1]  # Name
            key_email = key_values[2] # Email
            key_id = key_values[3]    # Key ID (last 8 chars)
            
            # Update key info display
            self.key_info_text.delete(1.0, tk.END)
            
            try:
                # Get key details based on type
                if key_type == "Public":
                    keys = self.key_generator.list_keys(secret=False)
                else:
                    keys = self.key_generator.list_keys(secret=True)
                
                # Find the selected key by key ID (more reliable than name/email matching)
                selected_key = None
                for key in keys:
                    if key['keyid'].endswith(key_id):
                        selected_key = key
                        break
                
                if selected_key:
                    # For private keys, require passphrase
                    if key_type == "Private":
                        from tkinter import simpledialog
                        passphrase = simpledialog.askstring(
                            "Private Key Access", 
                            "Enter passphrase to view private key information:",
                            show='*'
                        )
                        if not passphrase:
                            self.key_info_text.insert(tk.END, "❌ Private key information access cancelled.\n\nPassphrase required to view private key details.")
                            return
                        
                        # Verify passphrase by attempting to use the key
                        try:
                            # Test the passphrase by trying to export the private key
                            test_result = self.key_generator.export_private_key(selected_key['fingerprint'], passphrase)
                            if not test_result.get('success', False):
                                self.key_info_text.insert(tk.END, "❌ Incorrect passphrase.\n\nCannot display private key information.")
                                return
                        except Exception as e:
                            self.key_info_text.insert(tk.END, f"❌ Passphrase verification failed.\n\nError: {str(e)}")
                            return
                    
                    # Display key information
                    info_text = f"🔑 {key_type} Key Information\n"
                    info_text += "=" * 50 + "\n\n"
                    
                    # Basic information
                    info_text += f"📋 Key ID: {selected_key.get('keyid', 'N/A')}\n"
                    info_text += f"🔍 Fingerprint: {selected_key.get('fingerprint', 'N/A')}\n"
                    info_text += f"🔐 Algorithm: {selected_key.get('algo', 'RSA')}\n"
                    info_text += f"📏 Key Length: {selected_key.get('length', 'N/A')} bits\n"
                    
                    # User IDs
                    if selected_key.get('uids'):
                        info_text += f"\n👤 User IDs:\n"
                        for uid in selected_key['uids']:
                            info_text += f"   • {uid}\n"
                    
                    # Creation date
                    if selected_key.get('created') or selected_key.get('date'):
                        creation_timestamp = selected_key.get('created') or selected_key.get('date')
                        try:
                            import datetime
                            if isinstance(creation_timestamp, str):
                                # Try to parse as timestamp
                                creation_timestamp = float(creation_timestamp)
                            creation_date = datetime.datetime.fromtimestamp(creation_timestamp)
                            info_text += f"\n📅 Created: {creation_date.strftime('%Y-%m-%d %H:%M:%S')}\n"
                        except:
                            info_text += f"\n📅 Created: {creation_timestamp}\n"
                    
                    # Expiration
                    if selected_key.get('expires'):
                        if selected_key['expires'] == '' or selected_key['expires'] == '0':
                            info_text += f"⏰ Expires: Never\n"
                        else:
                            try:
                                import datetime
                                exp_timestamp = float(selected_key['expires'])
                                exp_date = datetime.datetime.fromtimestamp(exp_timestamp)
                                info_text += f"⏰ Expires: {exp_date.strftime('%Y-%m-%d %H:%M:%S')}\n"
                            except:
                                info_text += f"⏰ Expires: {selected_key['expires']}\n"
                    
                    # Trust level
                    if selected_key.get('trust'):
                        trust_levels = {
                            'o': 'Unknown',
                            'i': 'Invalid',
                            'd': 'Disabled',
                            'r': 'Revoked',
                            'e': 'Expired',
                            '-': 'Unknown',
                            'q': 'Undefined',
                            'n': 'Never',
                            'm': 'Marginal',
                            'f': 'Full',
                            'u': 'Ultimate'
                        }
                        trust = trust_levels.get(selected_key['trust'], selected_key['trust'])
                        info_text += f"🛡️ Trust Level: {trust}\n"
                    
                    # Additional security info
                    info_text += f"\n🔒 Security Information:\n"
                    info_text += f"   • Key Type: {key_type}\n"
                    
                    if key_type == "Private":
                        info_text += f"   • Status: Private key available for decryption\n"
                        info_text += f"   • Usage: Can decrypt messages and sign data\n"
                    else:
                        info_text += f"   • Status: Public key only\n"
                        info_text += f"   • Usage: Can encrypt messages for this recipient\n"
                    
                    # Usage instructions
                    info_text += f"\n📖 Usage Instructions:\n"
                    if key_type == "Private":
                        info_text += f"   • Use this key to decrypt messages sent to you\n"
                        info_text += f"   • Export the public key to share with others\n"
                        info_text += f"   • Keep the private key secure and never share it\n"
                    else:
                        info_text += f"   • Use this key to encrypt messages for the recipient\n"
                        info_text += f"   • This is someone else's public key\n"
                        info_text += f"   • You cannot decrypt messages with this key\n"
                    
                    self.key_info_text.insert(tk.END, info_text)
                else:
                    self.key_info_text.insert(tk.END, "❌ Key information not found\n\nThe selected key could not be located in the keyring.")
                    
            except Exception as e:
                error_text = f"❌ Error loading key information:\n{str(e)}\n\nPlease try refreshing the key list."
                self.key_info_text.insert(tk.END, error_text)
        else:
            # No selection
            self.key_info_text.delete(1.0, tk.END)
            self.key_info_text.insert(tk.END, "Select a key from the list above to view detailed information")
    
    def refresh_key_list(self):
        """Refresh the key list"""
        # Clear current items
        for item in self.key_tree.get_children():
            self.key_tree.delete(item)
        
        # Load keys from backend
        try:
            public_keys = self.key_generator.list_keys(secret=False)
            private_keys = self.key_generator.list_keys(secret=True)
            
            # Load contacts to get proper names
            contacts = self.load_contacts()
            
            # Create fingerprint to contact name mapping
            fingerprint_to_name = {}
            for fingerprint, contact_info in contacts.items():
                fingerprint_to_name[fingerprint] = contact_info['name']
            
            # Add public keys
            for key in public_keys:
                # Try to get contact name first, fallback to key UID
                display_name = fingerprint_to_name.get(key['fingerprint'], None)
                
                if not display_name:
                    # Fallback to parsing UID
                    name = key['uids'][0] if key['uids'] else 'Unknown'
                    if '<' in name and '>' in name:
                        display_name = name.split('<')[0].strip()
                    else:
                        display_name = name
                
                # Extract email from UID
                email = ''
                if key['uids']:
                    uid = key['uids'][0]
                    if '<' in uid and '>' in uid:
                        email = uid.split('<')[1].replace('>', '').strip()
                
                self.key_tree.insert('', 'end', values=(
                    'Public',
                    display_name,
                    email,
                    key['keyid'][-8:],  # Last 8 chars of key ID
                    key['date']
                ))
            
            # Add private keys
            for key in private_keys:
                # Try to get contact name first, fallback to key UID
                display_name = fingerprint_to_name.get(key['fingerprint'], None)
                
                if not display_name:
                    # Fallback to parsing UID
                    name = key['uids'][0] if key['uids'] else 'Unknown'
                    if '<' in name and '>' in name:
                        display_name = name.split('<')[0].strip()
                    else:
                        display_name = name
                
                # Extract email from UID
                email = ''
                if key['uids']:
                    uid = key['uids'][0]
                    if '<' in uid and '>' in uid:
                        email = uid.split('<')[1].replace('>', '').strip()
                
                self.key_tree.insert('', 'end', values=(
                    'Private',
                    display_name,
                    email,
                    key['keyid'][-8:],  # Last 8 chars of key ID
                    key['date']
                ))
            
            # Update status
            total_keys = len(public_keys) + len(private_keys)
            self.key_count_var.set(f"Keys: {total_keys}")
            self.status_var.set("Key list refreshed")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to refresh key list: {str(e)}")
    
    def show_how_we_built_this(self):
        """Show the How We Built This documentation"""
        doc_window = tk.Toplevel(self.root)
        doc_window.title("How We Built This - PGP Encryption Tool v2.1")
        doc_window.geometry("900x700")
        doc_window.resizable(True, True)
        
        # Make it modal
        doc_window.transient(self.root)
        doc_window.grab_set()
        
        # Center the window
        doc_window.update_idletasks()
        x = (doc_window.winfo_screenwidth() // 2) - (900 // 2)
        y = (doc_window.winfo_screenheight() // 2) - (700 // 2)
        doc_window.geometry(f"900x700+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(doc_window, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Header
        header_label = ttk.Label(
            main_frame, 
            text="How We Built This - Technical Documentation", 
            font=('Arial', 16, 'bold')
        )
        header_label.grid(row=0, column=0, sticky=tk.W, pady=(0, 10))
        
        # Text widget with scrollbar
        text_frame = ttk.Frame(main_frame)
        text_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        text_frame.columnconfigure(0, weight=1)
        text_frame.rowconfigure(0, weight=1)
        
        text_widget = tk.Text(
            text_frame,
            wrap=tk.WORD,
            font=('Consolas', 10),
            bg='#f8f9fa',
            relief=tk.SUNKEN,
            borderwidth=2,
            padx=10,
            pady=10
        )
        
        scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
        text_widget.configure(yscrollcommand=scrollbar.set)
        
        text_widget.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        # Load and display documentation
        try:
            doc_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "HOW_WE_BUILT_THIS.md")
            if os.path.exists(doc_path):
                with open(doc_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                text_widget.insert(tk.END, content)
            else:
                text_widget.insert(tk.END, 
                    "📚 How We Built This - PGP Encryption Tool v2.1\n\n"
                    "Documentation file not found. This would normally contain:\n\n"
                    "• Technical architecture details\n"
                    "• Development process and methodology\n"
                    "• Security considerations and threat model\n"
                    "• Cryptographic implementation details\n"
                    "• Performance optimization strategies\n"
                    "• Testing and quality assurance procedures\n"
                    "• Future enhancement roadmap\n\n"
                    f"Developer: {APP_AUTHOR}\n"
                    f"Version: {APP_VERSION}\n"
                    "Date: January 2025"
                )
        except Exception as e:
            text_widget.insert(tk.END, f"Error loading documentation: {str(e)}")
        
        text_widget.config(state=tk.DISABLED)
        
        # Close button
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=0, pady=(10, 0))
        
        ttk.Button(
            button_frame, 
            text="Close", 
            command=doc_window.destroy
        ).pack()
    
    def show_about(self):
        """Show about dialog"""
        messagebox.showinfo(
            "About", 
            f"{APP_NAME} v{APP_VERSION}\n"
            f"Developed by {APP_AUTHOR}\n\n"
            "A secure offline PGP encryption tool\n\n"
            "Features:\n"
            "• PGP key generation with entropy collection\n"
            "• Message encryption/decryption\n"
            "• Key management and backup\n"
            "• Emergency data deletion\n"
            "• Complete offline operation"
        )
    
    def on_closing(self):
        """Handle application closing"""
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            # Cleanup
            try:
                self.key_generator.cleanup()
            except:
                pass
            self.root.destroy()
    
    # Contacts Management Methods
    def add_contact_dialog(self):
        """Show add contact dialog"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Contact")
        dialog.geometry("400x300")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Contact name
        ttk.Label(main_frame, text="Contact Name:").grid(row=0, column=0, sticky=tk.W, pady=5)
        name_var = tk.StringVar()
        name_entry = ttk.Entry(main_frame, textvariable=name_var, width=40)
        name_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # IRC nickname (optional)
        ttk.Label(main_frame, text="IRC Nickname (optional):").grid(row=1, column=0, sticky=tk.W, pady=5)
        irc_nick_var = tk.StringVar()
        irc_nick_entry = ttk.Entry(main_frame, textvariable=irc_nick_var, width=40)
        irc_nick_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Public key
        ttk.Label(main_frame, text="Public Key:").grid(row=2, column=0, sticky=tk.NW, pady=5)
        key_text = tk.Text(main_frame, height=10, width=50)
        key_scroll = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=key_text.yview)
        key_text.configure(yscrollcommand=key_scroll.set)
        key_text.grid(row=2, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5, padx=(10, 0))
        key_scroll.grid(row=2, column=2, sticky=(tk.N, tk.S), pady=5)
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(2, weight=1)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=3, pady=(20, 0))
        
        def save_contact():
            name = name_var.get().strip()
            irc_nickname = irc_nick_var.get().strip()
            public_key = key_text.get(1.0, tk.END).strip()
            
            if not name:
                messagebox.showerror("Error", "Please enter a contact name")
                return
            
            if not public_key:
                messagebox.showerror("Error", "Please enter the contact's public key")
                return
            
            # Import the public key
            result = self.key_generator.import_key(public_key)
            if result['success']:
                # Save contact info with IRC nickname
                self.save_contact_info(name, result['fingerprint'], irc_nickname)
                messagebox.showinfo("Success", f"Contact '{name}' added successfully!")
                dialog.destroy()
                self.refresh_contacts_list()
                self.refresh_key_list()  # Refresh keys to show contact name
                self.update_recipient_list()  # Update recipient list
                if hasattr(self, 'refresh_chat_contacts'):
                    self.refresh_chat_contacts()  # Update chat contacts
            else:
                messagebox.showerror("Error", f"Failed to import key: {result['error']}")
        
        ttk.Button(button_frame, text="Save Contact", command=save_contact).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT)
        
        # Focus on name entry
        name_entry.focus()
    
    def save_contact_info(self, name, fingerprint, irc_nickname=""):
        """Save contact information to encrypted file"""
        import datetime
        
        # Load existing contacts
        contacts = self.load_contacts()
        
        # Add new contact
        contacts[fingerprint] = {
            "name": name,
            "fingerprint": fingerprint,
            "added_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "irc_nickname": irc_nickname  # Add IRC nickname field for chat integration
        }
        
        # Save contacts using encrypted storage
        try:
            if hasattr(self.key_generator, 'data_manager') and self.key_generator.data_manager:
                self.key_generator.data_manager.save_data("contacts.json", contacts)
            else:
                # Fallback to unencrypted storage if data manager not available
                import json
                contacts_file = os.path.join(self.key_generator.gnupg_home, "contacts.json")
                with open(contacts_file, 'w') as f:
                    json.dump(contacts, f, indent=2)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save contact: {str(e)}")
    
    def load_contacts(self):
        """Load contacts from encrypted file"""
        try:
            if hasattr(self.key_generator, 'data_manager') and self.key_generator.data_manager:
                # Try to load from encrypted storage first
                contacts = self.key_generator.data_manager.load_data("contacts.json", {})
                if contacts:
                    return contacts
            
            # Fallback to unencrypted file (for migration)
            import json
            contacts_file = os.path.join(self.key_generator.gnupg_home, "contacts.json")
            
            if os.path.exists(contacts_file):
                try:
                    with open(contacts_file, 'r') as f:
                        contacts = json.load(f)
                    
                    # Migrate to encrypted storage if data manager is available
                    if hasattr(self.key_generator, 'data_manager') and self.key_generator.data_manager and contacts:
                        self.key_generator.data_manager.save_data("contacts.json", contacts)
                        # Optionally remove old unencrypted file
                        # os.remove(contacts_file)
                    
                    return contacts
                except (json.JSONDecodeError, IOError):
                    pass
        except Exception as e:
            print(f"Warning: Failed to load contacts: {e}")
        
        return {}
    
    def refresh_contacts_list(self):
        """Refresh the contacts list"""
        # Clear current items
        for item in self.contacts_tree.get_children():
            self.contacts_tree.delete(item)
        
        try:
            contacts = self.load_contacts()
            public_keys = self.key_generator.list_keys(secret=False)
            
            # Create a map of fingerprints to key info
            key_map = {key['fingerprint']: key for key in public_keys}
            
            # Add contacts to tree
            for fingerprint, contact_info in contacts.items():
                if fingerprint in key_map:
                    key_info = key_map[fingerprint]
                    irc_nick = contact_info.get('irc_nickname', '')
                    display_nick = irc_nick if irc_nick else '(none)'
                    self.contacts_tree.insert('', 'end', values=(
                        contact_info['name'],
                        key_info['keyid'][-8:],  # Last 8 chars of key ID
                        display_nick,  # IRC nickname
                        contact_info['added_date']
                    ), tags=(fingerprint,))
            
            # Update status
            self.contact_count_var.set(f"Contacts: {len(contacts)}")
            self.status_var.set("Contacts list refreshed")
            
            # Also update recipient list in compose message
            self.update_recipient_list()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to refresh contacts list: {str(e)}")
    
    def remove_contact(self):
        """Remove selected contact"""
        selection = self.contacts_tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a contact to remove")
            return
        
        item = selection[0]
        contact_name = self.contacts_tree.item(item)['values'][0]
        fingerprint = self.contacts_tree.item(item)['tags'][0]
        
        result = messagebox.askyesno(
            "Remove Contact", 
            f"Are you sure you want to remove contact '{contact_name}'?\n\n"
            "This will remove the contact from your list but keep the public key."
        )
        
        if result:
            # Remove from contacts file
            import json
            contacts_file = os.path.join(self.key_generator.gnupg_home, "contacts.json")
            
            try:
                contacts = self.load_contacts()
                if fingerprint in contacts:
                    del contacts[fingerprint]
                    
                    with open(contacts_file, 'w') as f:
                        json.dump(contacts, f, indent=2)
                    
                    self.refresh_contacts_list()
                    messagebox.showinfo("Success", f"Contact '{contact_name}' removed successfully!")
                    
            except Exception as e:
                messagebox.showerror("Error", f"Failed to remove contact: {str(e)}")
    
    def import_contact_key(self):
        """Import a public key file for a contact"""
        from tkinter import filedialog
        
        file_path = filedialog.askopenfilename(
            title="Import Public Key",
            filetypes=[
                ("PGP Key files", "*.asc *.pgp *.gpg"),
                ("Text files", "*.txt"),
                ("All files", "*.*")
            ]
        )
        
        if file_path:
            try:
                with open(file_path, 'r') as f:
                    key_data = f.read()
                
                # Show add contact dialog with pre-filled key
                self.add_contact_dialog_with_key(key_data)
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to read key file: {str(e)}")
    
    def add_contact_dialog_with_key(self, key_data):
        """Show add contact dialog with pre-filled key data"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Contact")
        dialog.geometry("400x350")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Contact name
        ttk.Label(main_frame, text="Contact Name:").grid(row=0, column=0, sticky=tk.W, pady=5)
        name_var = tk.StringVar()
        name_entry = ttk.Entry(main_frame, textvariable=name_var, width=40)
        name_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # IRC nickname (optional)
        ttk.Label(main_frame, text="IRC Nickname (optional):").grid(row=1, column=0, sticky=tk.W, pady=5)
        irc_nick_var = tk.StringVar()
        irc_nick_entry = ttk.Entry(main_frame, textvariable=irc_nick_var, width=40)
        irc_nick_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Public key (pre-filled)
        ttk.Label(main_frame, text="Public Key:").grid(row=2, column=0, sticky=tk.NW, pady=5)
        key_text = tk.Text(main_frame, height=10, width=50)
        key_scroll = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=key_text.yview)
        key_text.configure(yscrollcommand=key_scroll.set)
        key_text.grid(row=2, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5, padx=(10, 0))
        key_scroll.grid(row=2, column=2, sticky=(tk.N, tk.S), pady=5)
        
        # Pre-fill the key data
        key_text.insert(1.0, key_data)
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(2, weight=1)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=3, pady=(20, 0))
        
        def save_contact():
            name = name_var.get().strip()
            irc_nickname = irc_nick_var.get().strip()
            public_key = key_text.get(1.0, tk.END).strip()
            
            if not name:
                messagebox.showerror("Error", "Please enter a contact name")
                return
            
            if not public_key:
                messagebox.showerror("Error", "Please enter the contact's public key")
                return
            
            # Import the public key
            result = self.key_generator.import_key(public_key)
            if result['success']:
                # Save contact info with IRC nickname
                self.save_contact_info(name, result['fingerprint'], irc_nickname)
                messagebox.showinfo("Success", f"Contact '{name}' added successfully!")
                dialog.destroy()
                self.refresh_contacts_list()
                self.refresh_key_list()  # Refresh keys to show contact name
                self.update_recipient_list()  # Update recipient list
                if hasattr(self, 'refresh_chat_contacts'):
                    self.refresh_chat_contacts()  # Update chat contacts
            else:
                messagebox.showerror("Error", f"Failed to import key: {result['error']}")
        
        ttk.Button(button_frame, text="Save Contact", command=save_contact).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT)
        
        # Focus on name entry
        name_entry.focus()
    
    def on_contact_selected(self, event):
        """Handle contact selection"""
        selection = self.contacts_tree.selection()
        if selection:
            item = selection[0]
            contact_name = self.contacts_tree.item(item)['values'][0]
            key_id = self.contacts_tree.item(item)['values'][1]
            added_date = self.contacts_tree.item(item)['values'][2]
            fingerprint = self.contacts_tree.item(item)['tags'][0]
            
            # Update contact info display
            self.contact_info_text.delete(1.0, tk.END)
            info = f"Contact: {contact_name}\n"
            info += f"Key ID: {key_id}\n"
            info += f"Added: {added_date}\n"
            info += f"Fingerprint: {fingerprint}"
            self.contact_info_text.insert(tk.END, info)

    def run(self):
        """Start the application"""
        print("Debug: Starting application")
        
        # Show login dialog first (before showing main window)
        from .login_dialog import LoginDialog
        
        login_dialog = LoginDialog()  # Don't pass self.root as parent since it's hidden
        login_result = login_dialog.show()
        
        print(f"Debug: Login dialog returned: {login_result}")
        
        if not login_result:
            # User cancelled login or failed authentication
            print("Debug: Login failed or cancelled, destroying main window")
            self.root.destroy()
            return
        
        print("Debug: Login successful, showing main window")
        
        # Authentication successful - now show the main window
        self.root.deiconify()  # Show the hidden window
        self.root.lift()       # Bring to front
        self.root.focus_force() # Give focus
        
        print("Debug: Main window should now be visible")
        
        # Get the master password from the login dialog
        # Note: For security, we should get the actual password from the login dialog
        # For now, we'll initialize the data manager properly
        try:
            if hasattr(self.key_generator, 'pgp_handler') and hasattr(self.key_generator.pgp_handler, 'handler'):
                # The data manager should already be initialized with encryption from the login process
                # We just need to ensure it's properly set up
                pass
        except Exception as e:
            print(f"Warning: Failed to initialize encryption: {e}")
        
        # Load message history
        self.load_message_history()
        
        # Initial setup
        self.refresh_key_list()
        self.refresh_contacts_list()
        
        print("Debug: Starting main window mainloop")
        
        # Start the main loop
        self.root.mainloop()
    
    # ===== SECURE CHAT METHODS =====
    
    def generate_chat_nickname(self):
        """Generate a random IRC nickname"""
        prefix = "PGPUser_"
        suffix = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))
        nickname = prefix + suffix
        self.chat_nickname_var.set(nickname)
    
    def toggle_chat_connection(self):
        """Toggle IRC connection"""
        if self.secure_chat and self.secure_chat.irc_client.connected:
            self.disconnect_from_chat()
        else:
            self.connect_to_chat()
    
    def connect_to_chat(self):
        """Connect to IRC for secure chat"""
        if not SECURE_CHAT_AVAILABLE:
            messagebox.showerror("Error", "Secure chat functionality is not available")
            return
            
        try:
            # Initialize secure chat if not already done
            if not self.secure_chat:
                # Get the PGP handler from key generator
                pgp_handler = self.key_generator.pgp_handler
                self.secure_chat = SecureChatHandler(pgp_handler)
                
                # Set up callbacks
                self.secure_chat.on_message_callback = self.on_chat_message_received
                self.secure_chat.on_error_callback = self.on_chat_error
            
            # Set save history preference
            self.secure_chat.save_history = self.chat_save_history_var.get()
            
            # Get connection details
            network = self.chat_network_var.get()
            nickname = self.chat_nickname_var.get().strip()
            
            if not nickname:
                messagebox.showerror("Error", "Please enter a nickname")
                return
            
            # Update UI
            self.chat_status_var.set("Connecting...")
            self.chat_status_label.configure(foreground="orange")
            self.chat_connect_button.configure(text="Connecting...", state="disabled")
            self.root.update()
            
            # Connect to IRC
            self.secure_chat.connect_to_irc(network, nickname)
            
            # Update UI on successful connection
            self.chat_status_var.set(f"Connected to {network}")
            self.chat_status_label.configure(foreground="green")
            self.chat_connect_button.configure(text="Disconnect", state="normal")
            self.chat_send_button.configure(state="normal")
            
            # Add system message to chat log
            self.add_chat_log_message("SYSTEM", f"Connected to {network} as {nickname}")
            
            # Initialize group chat
            if self.initialize_group_chat():
                self.add_chat_log_message("SYSTEM", "Group chat initialized")
            
        except Exception as e:
            self.chat_status_var.set("Connection failed")
            self.chat_status_label.configure(foreground="red")
            self.chat_connect_button.configure(text="Connect", state="normal")
            messagebox.showerror("Connection Error", f"Failed to connect: {str(e)}")
    
    def disconnect_from_chat(self):
        """Disconnect from IRC"""
        try:
            if self.secure_chat:
                self.secure_chat.disconnect_from_irc()
            
            # Update UI
            self.chat_status_var.set("Disconnected")
            self.chat_status_label.configure(foreground="red")
            self.chat_connect_button.configure(text="Connect", state="normal")
            self.chat_send_button.configure(state="disabled")
            
            # Add system message to chat log
            self.add_chat_log_message("SYSTEM", "Disconnected from IRC")
            
        except Exception as e:
            messagebox.showerror("Disconnect Error", f"Failed to disconnect: {str(e)}")
    
    def add_chat_contact_dialog(self):
        """Show dialog to add a new chat contact"""
        dialog = tk.Toplevel(self.root)
        dialog.title("Add Chat Contact")
        dialog.geometry("500x400")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() // 2) - (dialog.winfo_width() // 2)
        y = (dialog.winfo_screenheight() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(dialog, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        dialog.columnconfigure(0, weight=1)
        dialog.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Contact name
        ttk.Label(main_frame, text="Contact Name:").grid(row=0, column=0, sticky=tk.W, pady=5)
        name_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=name_var, width=30).grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5)
        
        # IRC nickname
        ttk.Label(main_frame, text="IRC Nickname:").grid(row=1, column=0, sticky=tk.W, pady=5)
        irc_nick_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=irc_nick_var, width=30).grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5)
        
        # Method selection
        ttk.Label(main_frame, text="Key Method:").grid(row=2, column=0, sticky=tk.W, pady=5)
        method_var = tk.StringVar(value="fingerprint")
        method_frame = ttk.Frame(main_frame)
        method_frame.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Radiobutton(method_frame, text="Use Fingerprint", variable=method_var, 
                       value="fingerprint").grid(row=0, column=0, sticky=tk.W)
        ttk.Radiobutton(method_frame, text="Import Public Key", variable=method_var, 
                       value="public_key").grid(row=0, column=1, sticky=tk.W, padx=(20, 0))
        
        # Fingerprint entry
        ttk.Label(main_frame, text="PGP Fingerprint:").grid(row=3, column=0, sticky=tk.W, pady=5)
        fingerprint_var = tk.StringVar()
        ttk.Entry(main_frame, textvariable=fingerprint_var, width=30).grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5)
        
        # Public key text area
        ttk.Label(main_frame, text="Public Key:").grid(row=4, column=0, sticky=(tk.W, tk.N), pady=5)
        key_frame = ttk.Frame(main_frame)
        key_frame.grid(row=4, column=1, sticky=(tk.W, tk.E, tk.N, tk.S), pady=5)
        key_frame.columnconfigure(0, weight=1)
        key_frame.rowconfigure(0, weight=1)
        main_frame.rowconfigure(4, weight=1)
        
        public_key_text = tk.Text(key_frame, height=8, width=50)
        public_key_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        key_scroll = ttk.Scrollbar(key_frame, orient="vertical", command=public_key_text.yview)
        key_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        public_key_text.configure(yscrollcommand=key_scroll.set)
        
        # Paste button
        ttk.Button(key_frame, text="Paste from Clipboard", 
                  command=lambda: self.paste_to_text_widget(public_key_text)).grid(row=1, column=0, pady=5)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=5, column=0, columnspan=2, pady=10)
        
        def add_contact():
            try:
                name = name_var.get().strip()
                irc_nick = irc_nick_var.get().strip()
                
                if not name or not irc_nick:
                    messagebox.showerror("Error", "Please enter both name and IRC nickname")
                    return
                
                if method_var.get() == "fingerprint":
                    fingerprint = fingerprint_var.get().strip()
                    if not fingerprint:
                        messagebox.showerror("Error", "Please enter PGP fingerprint")
                        return
                    
                    # Add contact with fingerprint
                    if self.secure_chat:
                        self.secure_chat.add_contact(name, irc_nick, pgp_fingerprint=fingerprint)
                    else:
                        # Store for later when chat is initialized
                        self.chat_contacts[irc_nick] = {
                            "name": name,
                            "fingerprint": fingerprint,
                            "public_key": None
                        }
                else:
                    public_key = public_key_text.get("1.0", tk.END).strip()
                    if not public_key:
                        messagebox.showerror("Error", "Please enter public key")
                        return
                    
                    # Add contact with public key
                    if self.secure_chat:
                        self.secure_chat.add_contact(name, irc_nick, public_key=public_key)
                    else:
                        # Store for later when chat is initialized
                        self.chat_contacts[irc_nick] = {
                            "name": name,
                            "fingerprint": None,
                            "public_key": public_key
                        }
                
                # Update contacts list
                self.refresh_chat_contacts()
                
                messagebox.showinfo("Success", f"Contact '{name}' added successfully")
                dialog.destroy()
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add contact: {str(e)}")
        
        ttk.Button(button_frame, text="Add Contact", command=add_contact).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).grid(row=0, column=1, padx=5)
    
    def paste_to_text_widget(self, text_widget):
        """Paste clipboard content to text widget"""
        try:
            clipboard_content = self.root.clipboard_get()
            text_widget.delete("1.0", tk.END)
            text_widget.insert("1.0", clipboard_content)
        except tk.TclError:
            messagebox.showwarning("Warning", "Clipboard is empty")
    
    def refresh_chat_contacts(self):
        """Refresh the chat contacts list"""
        self.chat_contacts_listbox.delete(0, tk.END)
        self.chat_target_combo['values'] = []
        
        contact_names = []
        
        # Add contacts from unified contacts system (with IRC nicknames)
        try:
            unified_contacts = self.load_contacts()
            for fingerprint, contact_info in unified_contacts.items():
                irc_nick = contact_info.get('irc_nickname', '').strip()
                if irc_nick:  # Only show contacts with IRC nicknames
                    display_name = f"{contact_info['name']} ({irc_nick})"
                    self.chat_contacts_listbox.insert(tk.END, display_name)
                    contact_names.append(irc_nick)
                    
                    # Add to secure chat if connected
                    if self.secure_chat and irc_nick not in self.secure_chat.contacts:
                        self.secure_chat.add_contact(contact_info['name'], irc_nick, pgp_fingerprint=fingerprint)
        except Exception as e:
            print(f"Warning: Failed to load unified contacts: {e}")
        
        # Add contacts from secure chat (legacy)
        if self.secure_chat:
            for nickname, contact in self.secure_chat.contacts.items():
                if nickname not in contact_names:  # Avoid duplicates
                    display_name = f"{contact.name} ({nickname})"
                    self.chat_contacts_listbox.insert(tk.END, display_name)
                    contact_names.append(nickname)
        
        # Add stored contacts (not yet added to secure chat)
        for nickname, contact_info in self.chat_contacts.items():
            if nickname not in contact_names:  # Avoid duplicates
                display_name = f"{contact_info['name']} ({nickname})"
                self.chat_contacts_listbox.insert(tk.END, display_name)
                contact_names.append(nickname)
        
        # Update target combo
        self.chat_target_combo['values'] = contact_names
    
    def start_chat_with_contact(self, event):
        """Start chat with selected contact"""
        selection = self.chat_contacts_listbox.curselection()
        if selection:
            contact_text = self.chat_contacts_listbox.get(selection[0])
            # Extract nickname from "Name (nickname)" format
            nickname = contact_text.split('(')[-1].rstrip(')')
            self.chat_target_var.set(nickname)
    
    def send_chat_message(self, event=None):
        """Send encrypted chat message"""
        try:
            if not self.secure_chat or not self.secure_chat.irc_client.connected:
                messagebox.showerror("Error", "Not connected to IRC")
                return
            
            target = self.chat_target_var.get().strip()
            message = self.chat_message_var.get().strip()
            
            if not target:
                messagebox.showerror("Error", "Please select a chat target")
                return
            
            if not message:
                return  # Don't send empty messages
            
            # Send secure message
            self.secure_chat.send_secure_message(target, message)
            
            # Add to chat log
            self.add_chat_log_message("You", f"→ {target}: {message}", encrypted=True)
            
            # Save to message history if enabled
            if self.chat_save_history_var.get():
                self.add_to_message_history(
                    msg_type="Chat Sent",
                    subject=f"Chat to {target}",
                    recipient=target,
                    date=time.strftime("%Y-%m-%d %H:%M:%S"),
                    full_content=message
                )
            
            # Clear message input
            self.chat_message_var.set("")
            
        except Exception as e:
            messagebox.showerror("Send Error", f"Failed to send message: {str(e)}")
    
    def on_chat_message_received(self, chat_message):
        """Handle received chat message"""
        try:
            # Add to chat log
            encryption_status = "🔒" if chat_message.encrypted else "📝"
            verification_status = "✓" if chat_message.verified else ""
            
            sender_display = f"{chat_message.sender} {encryption_status}{verification_status}"
            self.add_chat_log_message(sender_display, chat_message.content, 
                                    encrypted=chat_message.encrypted)
            
            # Save to message history if enabled
            if self.chat_save_history_var.get():
                self.add_to_message_history(
                    msg_type="Chat Received",
                    subject=f"Chat from {chat_message.sender}",
                    recipient=chat_message.sender,
                    date=time.strftime("%Y-%m-%d %H:%M:%S"),
                    full_content=chat_message.content
                )
            
        except Exception as e:
            self.add_chat_log_message("ERROR", f"Failed to process message: {str(e)}")
    
    def on_chat_error(self, error_message):
        """Handle chat errors"""
        self.add_chat_log_message("ERROR", error_message)
    
    def add_chat_log_message(self, sender, message, encrypted=False):
        """Add message to chat log"""
        try:
            self.chat_log_text.configure(state=tk.NORMAL)
            
            # Add timestamp
            timestamp = time.strftime("%H:%M:%S")
            
            # Format message
            if sender == "SYSTEM":
                formatted_message = f"[{timestamp}] SYSTEM: {message}\n"
                self.chat_log_text.insert(tk.END, formatted_message)
            elif sender == "ERROR":
                formatted_message = f"[{timestamp}] ERROR: {message}\n"
                self.chat_log_text.insert(tk.END, formatted_message)
            else:
                encryption_indicator = " 🔒" if encrypted else ""
                formatted_message = f"[{timestamp}] {sender}{encryption_indicator}: {message}\n"
                self.chat_log_text.insert(tk.END, formatted_message)
            
            # Scroll to bottom
            self.chat_log_text.see(tk.END)
            self.chat_log_text.configure(state=tk.DISABLED)
            
        except Exception as e:
            print(f"Error adding chat log message: {e}")

    # Group Chat Methods
    def initialize_group_chat(self):
        """Initialize group chat system"""
        try:
            # Use absolute import instead of relative import
            import sys
            import os
            
            # Add the parent directory to sys.path if not already there
            parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if parent_dir not in sys.path:
                sys.path.insert(0, parent_dir)
            
            from chat.group_chat import GroupChatHandler
            
            if self.secure_chat:
                # Create group chat handler using the same PGP handler
                self.group_chat = GroupChatHandler(self.secure_chat.pgp_handler)
                
                # Copy IRC client from secure chat
                self.group_chat.irc_client = self.secure_chat.irc_client
                self.group_chat.connected = self.secure_chat.irc_client.connected if self.secure_chat.irc_client else False
                
                # Set up group chat callbacks
                self.group_chat.on_group_message_callback = self.on_group_message_received
                self.group_chat.on_group_join_callback = self.on_group_joined
                self.group_chat.on_group_leave_callback = self.on_group_left
                
                # Load existing groups
                groups_file = os.path.join(self.key_generator.gnupg_home, "groups.json")
                if os.path.exists(groups_file):
                    self.group_chat.load_groups_from_file(groups_file)
                
                # Refresh groups list
                self.refresh_groups_list()
                
                # Enable group chat controls
                self.group_send_button.config(state="normal" if self.group_chat.current_group else "disabled")
                
                return True
        except Exception as e:
            print(f"Warning: Could not initialize group chat: {e}")
            return False
    
    def create_group_dialog(self):
        """Show create group dialog"""
        if not self.group_chat:
            messagebox.showerror("Error", "Group chat not initialized. Please connect to IRC first.")
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Create Group")
        dialog.geometry("400x300")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Group name
        ttk.Label(main_frame, text="Group Name:").grid(row=0, column=0, sticky=tk.W, pady=5)
        name_var = tk.StringVar()
        name_entry = ttk.Entry(main_frame, textvariable=name_var, width=30)
        name_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Description
        ttk.Label(main_frame, text="Description:").grid(row=1, column=0, sticky=tk.NW, pady=5)
        desc_text = tk.Text(main_frame, height=4, width=30)
        desc_text.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Privacy settings
        privacy_frame = ttk.LabelFrame(main_frame, text="Privacy Settings", padding="10")
        privacy_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=10)
        privacy_frame.columnconfigure(1, weight=1)
        
        is_private_var = tk.BooleanVar()
        ttk.Checkbutton(privacy_frame, text="Private Group", 
                       variable=is_private_var).grid(row=0, column=0, sticky=tk.W)
        
        ttk.Label(privacy_frame, text="Password (optional):").grid(row=1, column=0, sticky=tk.W, pady=5)
        password_var = tk.StringVar()
        password_entry = ttk.Entry(privacy_frame, textvariable=password_var, show="*", width=20)
        password_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Max members
        ttk.Label(privacy_frame, text="Max Members:").grid(row=2, column=0, sticky=tk.W, pady=5)
        max_members_var = tk.StringVar(value="50")
        max_members_entry = ttk.Entry(privacy_frame, textvariable=max_members_var, width=10)
        max_members_entry.grid(row=2, column=1, sticky=tk.W, pady=5, padx=(10, 0))
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=(20, 0))
        
        def create_group():
            name = name_var.get().strip()
            description = desc_text.get(1.0, tk.END).strip()
            is_private = is_private_var.get()
            password = password_var.get().strip() if is_private else None
            
            try:
                max_members = int(max_members_var.get())
                if max_members < 2 or max_members > 1000:
                    raise ValueError("Max members must be between 2 and 1000")
            except ValueError:
                messagebox.showerror("Error", "Invalid max members value")
                return
            
            if not name:
                messagebox.showerror("Error", "Please enter a group name")
                return
            
            # Create the group
            success, message = self.group_chat.create_group(name, description, is_private, password, max_members)
            if success:
                messagebox.showinfo("Success", f"Group '{name}' created successfully!")
                dialog.destroy()
                self.refresh_groups_list()
                self.save_groups_data()
            else:
                messagebox.showerror("Error", f"Failed to create group: {message}")
        
        ttk.Button(button_frame, text="Create Group", command=create_group).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT)
        
        # Focus on name entry
        name_entry.focus()
    
    def join_group_dialog(self):
        """Show join group dialog"""
        if not self.group_chat:
            messagebox.showerror("Error", "Group chat not initialized. Please connect to IRC first.")
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Join Group")
        dialog.geometry("350x200")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Group name
        ttk.Label(main_frame, text="Group Name:").grid(row=0, column=0, sticky=tk.W, pady=5)
        name_var = tk.StringVar()
        name_entry = ttk.Entry(main_frame, textvariable=name_var, width=25)
        name_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Password
        ttk.Label(main_frame, text="Password (if required):").grid(row=1, column=0, sticky=tk.W, pady=5)
        password_var = tk.StringVar()
        password_entry = ttk.Entry(main_frame, textvariable=password_var, show="*", width=25)
        password_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5, padx=(10, 0))
        
        # Configure grid weights
        main_frame.columnconfigure(1, weight=1)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=0, columnspan=2, pady=(20, 0))
        
        def join_group():
            name = name_var.get().strip()
            password = password_var.get().strip()
            
            if not name:
                messagebox.showerror("Error", "Please enter a group name")
                return
            
            # Join the group
            success, message = self.group_chat.join_group(name, password if password else None)
            if success:
                messagebox.showinfo("Success", f"Joined group '{name}' successfully!")
                dialog.destroy()
                self.refresh_groups_list()
                self.switch_to_group_by_name(name)
                self.save_groups_data()
            else:
                messagebox.showerror("Error", f"Failed to join group: {message}")
        
        ttk.Button(button_frame, text="Join Group", command=join_group).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Button(button_frame, text="Cancel", command=dialog.destroy).pack(side=tk.LEFT)
        
        # Focus on name entry
        name_entry.focus()
    
    def leave_current_group(self):
        """Leave the current group"""
        if not self.group_chat or not self.group_chat.current_group:
            messagebox.showwarning("Warning", "No group selected")
            return
        
        group_name = self.group_chat.current_group
        
        # Confirm leaving
        result = messagebox.askyesno("Confirm Leave", f"Are you sure you want to leave group '{group_name}'?")
        if not result:
            return
        
        # Leave the group
        success, message = self.group_chat.leave_group(group_name)
        if success:
            messagebox.showinfo("Success", f"Left group '{group_name}' successfully!")
            self.refresh_groups_list()
            self.update_group_display()
            self.save_groups_data()
        else:
            messagebox.showerror("Error", f"Failed to leave group: {message}")
    
    def switch_to_group(self, event):
        """Switch to selected group"""
        selection = self.groups_listbox.curselection()
        if selection:
            group_name = self.groups_listbox.get(selection[0])
            self.switch_to_group_by_name(group_name)
    
    def switch_to_group_by_name(self, group_name):
        """Switch to a specific group"""
        if not self.group_chat:
            return
        
        self.group_chat.current_group = group_name
        self.update_group_display()
        self.load_group_message_history(group_name)
        
        # Enable/disable send button
        self.group_send_button.config(state="normal")
        self.group_message_entry.config(state="normal")
    
    def update_group_display(self):
        """Update group display information"""
        if not self.group_chat or not self.group_chat.current_group:
            self.current_group_var.set("None")
            self.group_member_count_var.set("0 members")
            self.group_chat_title_var.set("Select a group to start chatting")
            self.group_send_button.config(state="disabled")
            self.group_message_entry.config(state="disabled")
            return
        
        group_name = self.group_chat.current_group
        group_info = self.group_chat.get_group_info(group_name)
        
        if group_info:
            self.current_group_var.set(group_name)
            member_count = len(group_info['members'])
            self.group_member_count_var.set(f"{member_count} members")
            self.group_chat_title_var.set(f"Group: {group_name}")
        else:
            self.current_group_var.set(group_name)
            self.group_member_count_var.set("Unknown members")
            self.group_chat_title_var.set(f"Group: {group_name}")
    
    def refresh_groups_list(self):
        """Refresh the groups list"""
        self.groups_listbox.delete(0, tk.END)
        
        if self.group_chat:
            groups = self.group_chat.list_groups()
            for group_name in groups:
                self.groups_listbox.insert(tk.END, group_name)
    
    def send_group_message(self, event=None):
        """Send a message to the current group"""
        if not self.group_chat or not self.group_chat.current_group:
            messagebox.showwarning("Warning", "No group selected")
            return
        
        message = self.group_message_var.get().strip()
        if not message:
            return  # Don't send empty messages
        
        group_name = self.group_chat.current_group
        
        # Send the message
        success, result_message = self.group_chat.send_group_message(group_name, message)
        if success:
            # Add to group chat log
            self.add_group_chat_log_message("You", f"→ {group_name}: {message}")
            
            # Save to message history if enabled
            if self.chat_save_history_var.get():
                self.add_to_message_history(
                    msg_type="Group Chat Sent",
                    subject=f"Group: {group_name}",
                    recipient=group_name,
                    date=time.strftime("%Y-%m-%d %H:%M:%S"),
                    full_content=message
                )
            
            # Clear message input
            self.group_message_var.set("")
        else:
            messagebox.showerror("Error", f"Failed to send message: {result_message}")
    
    def on_group_message_received(self, group_message):
        """Handle received group message"""
        try:
            # Add to group chat log
            encryption_status = "🔒" if group_message.encrypted else "📝"
            verification_status = "✓" if group_message.verified else ""
            
            sender_display = f"{group_message.sender} {encryption_status}{verification_status}"
            self.add_group_chat_log_message(sender_display, group_message.content)
            
            # Save to message history if enabled
            if self.chat_save_history_var.get():
                self.add_to_message_history(
                    msg_type="Group Chat Received",
                    subject=f"Group: {group_message.group_name}",
                    recipient=group_message.sender,
                    date=time.strftime("%Y-%m-%d %H:%M:%S"),
                    full_content=group_message.content
                )
            
        except Exception as e:
            self.add_group_chat_log_message("ERROR", f"Failed to process group message: {str(e)}")
    
    def add_group_chat_log_message(self, sender, message):
        """Add message to group chat log"""
        try:
            self.group_chat_log_text.configure(state=tk.NORMAL)
            
            # Add timestamp
            timestamp = time.strftime("%H:%M:%S")
            
            # Format message
            if sender == "SYSTEM":
                formatted_message = f"[{timestamp}] SYSTEM: {message}\n"
                self.group_chat_log_text.insert(tk.END, formatted_message)
            elif sender == "ERROR":
                formatted_message = f"[{timestamp}] ERROR: {message}\n"
                self.group_chat_log_text.insert(tk.END, formatted_message)
            else:
                formatted_message = f"[{timestamp}] {sender}: {message}\n"
                self.group_chat_log_text.insert(tk.END, formatted_message)
            
            # Scroll to bottom
            self.group_chat_log_text.see(tk.END)
            self.group_chat_log_text.configure(state=tk.DISABLED)
            
        except Exception as e:
            print(f"Error adding group chat message: {e}")
    
    def load_group_message_history(self, group_name):
        """Load message history for a group"""
        if not self.group_chat:
            return
        
        # Clear current log
        self.group_chat_log_text.configure(state=tk.NORMAL)
        self.group_chat_log_text.delete(1.0, tk.END)
        
        # Load history
        messages = self.group_chat.get_group_message_history(group_name)
        for message in messages[-50:]:  # Show last 50 messages
            encryption_status = "🔒" if message.encrypted else "📝"
            verification_status = "✓" if message.verified else ""
            
            sender_display = f"{message.sender} {encryption_status}{verification_status}"
            timestamp = time.strftime("%H:%M:%S", time.localtime(message.timestamp))
            formatted_message = f"[{timestamp}] {sender_display}: {message.content}\n"
            
            self.group_chat_log_text.insert(tk.END, formatted_message)
        
        self.group_chat_log_text.configure(state=tk.DISABLED)
        self.group_chat_log_text.see(tk.END)
    
    def on_group_joined(self, group_name, user):
        """Handle user joining group"""
        self.add_group_chat_log_message("SYSTEM", f"{user} joined the group")
        self.update_group_display()
    
    def on_group_left(self, group_name, user):
        """Handle user leaving group"""
        self.add_group_chat_log_message("SYSTEM", f"{user} left the group")
        self.update_group_display()
    
    def show_group_context_menu(self, event):
        """Show context menu for group"""
        selection = self.groups_listbox.curselection()
        if not selection:
            return
        
        group_name = self.groups_listbox.get(selection[0])
        
        # Create context menu
        context_menu = tk.Menu(self.root, tearoff=0)
        context_menu.add_command(label="Switch to Group", command=lambda: self.switch_to_group_by_name(group_name))
        context_menu.add_command(label="Manage Members", command=lambda: self.manage_group_members_dialog(group_name))
        context_menu.add_separator()
        context_menu.add_command(label="Leave Group", command=lambda: self.leave_group_by_name(group_name))
        
        # Show menu
        try:
            context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            context_menu.grab_release()
    
    def leave_group_by_name(self, group_name):
        """Leave a specific group"""
        result = messagebox.askyesno("Confirm Leave", f"Are you sure you want to leave group '{group_name}'?")
        if not result:
            return
        
        success, message = self.group_chat.leave_group(group_name)
        if success:
            messagebox.showinfo("Success", f"Left group '{group_name}' successfully!")
            self.refresh_groups_list()
            if self.group_chat.current_group == group_name:
                self.group_chat.current_group = None
                self.update_group_display()
            self.save_groups_data()
        else:
            messagebox.showerror("Error", f"Failed to leave group: {message}")
    
    def manage_group_members_dialog(self, group_name=None):
        """Show group members management dialog"""
        if not self.group_chat:
            messagebox.showerror("Error", "Group chat not initialized")
            return
        
        if not group_name:
            group_name = self.group_chat.current_group
        
        if not group_name:
            messagebox.showwarning("Warning", "No group selected")
            return
        
        group_info = self.group_chat.get_group_info(group_name)
        if not group_info:
            messagebox.showerror("Error", "Group information not found")
            return
        
        dialog = tk.Toplevel(self.root)
        dialog.title(f"Manage Members - {group_name}")
        dialog.geometry("500x400")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center dialog
        dialog.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (dialog.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (dialog.winfo_height() // 2)
        dialog.geometry(f"+{x}+{y}")
        
        # Main frame
        main_frame = ttk.Frame(dialog, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Group info
        info_frame = ttk.LabelFrame(main_frame, text="Group Information", padding="10")
        info_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        info_frame.columnconfigure(1, weight=1)
        
        ttk.Label(info_frame, text="Name:").grid(row=0, column=0, sticky=tk.W)
        ttk.Label(info_frame, text=group_info['name'], font=('Arial', 9, 'bold')).grid(row=0, column=1, sticky=tk.W, padx=(10, 0))
        
        ttk.Label(info_frame, text="Description:").grid(row=1, column=0, sticky=tk.W)
        ttk.Label(info_frame, text=group_info.get('description', 'No description')).grid(row=1, column=1, sticky=tk.W, padx=(10, 0))
        
        ttk.Label(info_frame, text="Creator:").grid(row=2, column=0, sticky=tk.W)
        ttk.Label(info_frame, text=group_info.get('creator', 'Unknown')).grid(row=2, column=1, sticky=tk.W, padx=(10, 0))
        
        # Members list
        members_frame = ttk.LabelFrame(main_frame, text="Members", padding="10")
        members_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        members_frame.columnconfigure(0, weight=1)
        members_frame.rowconfigure(0, weight=1)
        
        # Members treeview
        columns = ("Nickname", "Role")
        members_tree = ttk.Treeview(members_frame, columns=columns, show="headings", height=10)
        members_tree.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure columns
        members_tree.heading("Nickname", text="Nickname")
        members_tree.heading("Role", text="Role")
        members_tree.column("Nickname", width=200)
        members_tree.column("Role", width=100)
        
        # Scrollbar
        members_scroll = ttk.Scrollbar(members_frame, orient="vertical", command=members_tree.yview)
        members_scroll.grid(row=0, column=1, sticky=(tk.N, tk.S))
        members_tree.configure(yscrollcommand=members_scroll.set)
        
        # Populate members
        for member in group_info['members']:
            role = "Admin" if member in group_info['admins'] else "Member"
            if member == group_info['creator']:
                role = "Creator"
            members_tree.insert('', 'end', values=(member, role))
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=2, column=0, pady=(10, 0))
        
        ttk.Button(button_frame, text="Close", command=dialog.destroy).pack(side=tk.RIGHT)
    
    def save_groups_data(self):
        """Save groups data to file"""
        if self.group_chat:
            try:
                groups_file = os.path.join(self.key_generator.gnupg_home, "groups.json")
                self.group_chat.save_groups_to_file(groups_file)
            except Exception as e:
                print(f"Warning: Failed to save groups data: {e}")


def main():
    """Main entry point"""
    app = PGPToolMainWindow()
    app.run()


if __name__ == "__main__":
    main()
