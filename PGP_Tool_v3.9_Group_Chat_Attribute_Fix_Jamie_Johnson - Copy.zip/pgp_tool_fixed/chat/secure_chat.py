"""
Secure Chat Handler for PGP Tool
Combines IRC client with PGP encryption for secure messaging
"""

import json
import time
import uuid
from typing import Dict, List, Optional, Callable
from .irc_client import PGPIRCClient


class SecureChatMessage:
    """Represents a secure chat message"""
    
    def __init__(self, sender: str, recipient: str, content: str, 
                 message_id: str = None, timestamp: float = None):
        self.sender = sender
        self.recipient = recipient
        self.content = content
        self.message_id = message_id or str(uuid.uuid4())
        self.timestamp = timestamp or time.time()
        self.encrypted = False
        self.verified = False
        
    def to_dict(self):
        """Convert message to dictionary"""
        return {
            "sender": self.sender,
            "recipient": self.recipient,
            "content": self.content,
            "message_id": self.message_id,
            "timestamp": self.timestamp,
            "encrypted": self.encrypted,
            "verified": self.verified
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create message from dictionary"""
        msg = cls(
            sender=data["sender"],
            recipient=data["recipient"],
            content=data["content"],
            message_id=data["message_id"],
            timestamp=data["timestamp"]
        )
        msg.encrypted = data.get("encrypted", False)
        msg.verified = data.get("verified", False)
        return msg


class SecureChatContact:
    """Represents a secure chat contact"""
    
    def __init__(self, name: str, irc_nickname: str, pgp_fingerprint: str):
        self.name = name
        self.irc_nickname = irc_nickname
        self.pgp_fingerprint = pgp_fingerprint
        self.online = False
        self.last_seen = None
        
    def to_dict(self):
        """Convert contact to dictionary"""
        return {
            "name": self.name,
            "irc_nickname": self.irc_nickname,
            "pgp_fingerprint": self.pgp_fingerprint,
            "online": self.online,
            "last_seen": self.last_seen
        }
    
    @classmethod
    def from_dict(cls, data):
        """Create contact from dictionary"""
        contact = cls(
            name=data["name"],
            irc_nickname=data["irc_nickname"],
            pgp_fingerprint=data["pgp_fingerprint"]
        )
        contact.online = data.get("online", False)
        contact.last_seen = data.get("last_seen")
        return contact


class SecureChatHandler:
    """Handles secure IRC+PGP chat functionality"""
    
    def __init__(self, pgp_handler):
        self.pgp_handler = pgp_handler
        self.irc_client = PGPIRCClient()
        self.contacts = {}  # nickname -> SecureChatContact
        self.message_history = []  # List of SecureChatMessage
        self.save_history = True  # User preference for saving history
        
        # Message chunking support
        self.pending_chunks = {}  # message_id -> {chunks: {}, total: int, sender: str}
        self.chunk_timeout = 30  # seconds
        
        # Message markers for PGP detection
        self.PGP_MESSAGE_START = "-----BEGIN PGP MESSAGE-----"
        self.PGP_MESSAGE_END = "-----END PGP MESSAGE-----"
        
        # Callbacks
        self.on_message_callback = None
        self.on_contact_online_callback = None
        self.on_contact_offline_callback = None
        self.on_error_callback = None
        
        # Setup IRC callbacks
        self.setup_irc_callbacks()
        
    def setup_irc_callbacks(self):
        """Setup IRC client callbacks"""
        self.irc_client.set_message_callback(self._on_irc_message)
        self.irc_client.set_connect_callback(self._on_irc_connect)
        self.irc_client.set_disconnect_callback(self._on_irc_disconnect)
        self.irc_client.set_error_callback(self._on_irc_error)
        
    def add_contact(self, name: str, irc_nickname: str, pgp_fingerprint: str = None, public_key: str = None):
        """Add a secure chat contact"""
        if not pgp_fingerprint and not public_key:
            raise ValueError("Either PGP fingerprint or public key must be provided")
            
        # If public key is provided, import it and get fingerprint
        if public_key:
            try:
                # Import the public key
                import_result = self.pgp_handler.import_key(public_key)
                if not import_result:
                    raise ValueError("Failed to import public key")
                
                # Extract fingerprint from the imported key
                # Try to get fingerprint from the key text directly first
                pgp_fingerprint = self._extract_fingerprint_from_key_text(public_key)
                
                if not pgp_fingerprint:
                    # Fallback: get from key list
                    keys = self.pgp_handler.list_keys()
                    if keys:
                        # Get the last key (most recently imported)
                        last_key = keys[-1] if isinstance(keys, list) else keys
                        if hasattr(last_key, 'fingerprint'):
                            pgp_fingerprint = last_key.fingerprint
                        elif isinstance(last_key, dict) and 'fingerprint' in last_key:
                            pgp_fingerprint = last_key['fingerprint']
                        elif hasattr(last_key, 'fpr'):
                            pgp_fingerprint = last_key.fpr
                
                if not pgp_fingerprint:
                    raise ValueError("Could not determine fingerprint from imported key")
                    
            except Exception as e:
                raise ValueError(f"Failed to process public key: {str(e)}")
        
        contact = SecureChatContact(name, irc_nickname, pgp_fingerprint)
        self.contacts[irc_nickname] = contact
        return contact
    
    def _extract_fingerprint_from_key_text(self, public_key: str) -> str:
        """Extract fingerprint from public key text using simple parsing"""
        try:
            # Look for fingerprint in key comments or try to parse key structure
            lines = public_key.split('\n')
            
            # Sometimes fingerprints are in comments
            for line in lines:
                if 'fingerprint' in line.lower() or 'fpr' in line.lower():
                    # Extract hex characters that look like a fingerprint
                    import re
                    hex_match = re.search(r'([A-F0-9\s]{40,})', line.upper())
                    if hex_match:
                        fingerprint = hex_match.group(1).replace(' ', '')
                        if len(fingerprint) >= 40:
                            return fingerprint
            
            # If no fingerprint found in comments, we'll need to rely on the PGP handler
            return None
            
        except Exception:
            return None
    
    def _extract_fingerprint_from_key(self, public_key: str) -> str:
        """Extract fingerprint from public key text (legacy method)"""
        try:
            # This method is kept for compatibility but simplified
            return self._extract_fingerprint_from_key_text(public_key)
        except Exception:
            return None
        
    def remove_contact(self, irc_nickname: str):
        """Remove a contact"""
        if irc_nickname in self.contacts:
            del self.contacts[irc_nickname]
            
    def get_contact(self, irc_nickname: str) -> Optional[SecureChatContact]:
        """Get contact by IRC nickname"""
        return self.contacts.get(irc_nickname)
        
    def get_contacts_list(self) -> List[SecureChatContact]:
        """Get list of all contacts"""
        return list(self.contacts.values())
        
    def connect_to_irc(self, network: str, nickname: str = None):
        """Connect to IRC network"""
        return self.irc_client.connect_to_network(network, nickname)
        
    def disconnect_from_irc(self):
        """Disconnect from IRC"""
        self.irc_client.disconnect()
        
    def send_secure_message(self, recipient_nickname: str, message_content: str):
        """Send a PGP-encrypted message via IRC"""
        # Get contact info
        contact = self.get_contact(recipient_nickname)
        if not contact:
            raise ValueError(f"Unknown contact: {recipient_nickname}")
            
        # Get recipient's public key using the correct method
        try:
            # Use export_public_key method which exists in the PGP handler
            export_result = self.pgp_handler.export_public_key(contact.pgp_fingerprint)
            if not export_result or not export_result.get('success'):
                raise ValueError(f"No public key found for {contact.name}")
        except Exception as e:
            raise ValueError(f"Failed to get public key for {contact.name}: {str(e)}")
            
        # Create message object
        chat_message = SecureChatMessage(
            sender=self.irc_client.nickname,
            recipient=recipient_nickname,
            content=message_content
        )
        
        try:
            # Encrypt message with recipient's public key (using fingerprint as recipient)
            encrypt_result = self.pgp_handler.encrypt_message(
                message_content, 
                [contact.pgp_fingerprint]
            )
            
            if not encrypt_result or not encrypt_result.get('success'):
                raise RuntimeError(f"Failed to encrypt message: {encrypt_result.get('error', 'Unknown error')}")
            
            encrypted_content = encrypt_result['encrypted_message']
            
            # Encode encrypted message for IRC transmission and chunk if necessary
            encoded_message = self._encode_for_irc(encrypted_content)
            
            # Send message (chunked if necessary)
            self._send_chunked_message(recipient_nickname, encoded_message)
            
            # Mark as encrypted and add to history
            chat_message.encrypted = True
            if self.save_history:
                self.message_history.append(chat_message)
                
            return chat_message
            
        except Exception as e:
            raise RuntimeError(f"Failed to send secure message: {str(e)}")
    
    def _send_chunked_message(self, recipient_nickname: str, encoded_message: str):
        """Send a message in chunks if it's too long for IRC"""
        import uuid
        import time
        
        # IRC message limit is about 450 bytes to be safe (512 - overhead)
        max_chunk_size = 400  # Conservative limit
        
        if len(encoded_message) <= max_chunk_size:
            # Message fits in one chunk
            self.irc_client.send_private_message(recipient_nickname, encoded_message)
        else:
            # Need to chunk the message
            message_id = str(uuid.uuid4())[:8]  # Short unique ID
            chunks = []
            
            # Split message into chunks
            for i in range(0, len(encoded_message), max_chunk_size):
                chunk = encoded_message[i:i + max_chunk_size]
                chunks.append(chunk)
            
            total_chunks = len(chunks)
            
            # Send each chunk with metadata
            for chunk_num, chunk in enumerate(chunks):
                chunk_header = f"<PGP-CHUNK:{message_id}:{chunk_num + 1}:{total_chunks}>"
                chunk_message = f"{chunk_header}{chunk}"
                
                self.irc_client.send_private_message(recipient_nickname, chunk_message)
                
                # Small delay between chunks to avoid flooding
                if chunk_num < total_chunks - 1:
                    time.sleep(0.1)
    
    def _encode_for_irc(self, pgp_message: str) -> str:
        """Encode PGP message for IRC transmission (single line)"""
        import base64
        
        # Convert PGP message to base64 to make it IRC-safe
        encoded = base64.b64encode(pgp_message.encode('utf-8')).decode('ascii')
        
        # Add markers to identify it as an encoded PGP message
        return f"<PGP-ENCODED>{encoded}</PGP-ENCODED>"
    
    def _decode_from_irc(self, encoded_message: str) -> str:
        """Decode PGP message from IRC transmission"""
        import base64
        
        # Check if it's an encoded PGP message
        if encoded_message.startswith("<PGP-ENCODED>") and encoded_message.endswith("</PGP-ENCODED>"):
            # Extract the base64 content
            encoded_content = encoded_message[13:-14]  # Remove markers
            
            # Decode from base64
            try:
                decoded = base64.b64decode(encoded_content.encode('ascii')).decode('utf-8')
                return decoded
            except Exception:
                # If decoding fails, return original message
                return encoded_message
        
        # Not an encoded message, return as-is
        return encoded_message
            
    def _on_irc_message(self, sender_nickname: str, message_content: str):
        """Handle incoming IRC message"""
        # Check if it's a chunked message
        if message_content.startswith("<PGP-CHUNK:"):
            self._handle_chunk(sender_nickname, message_content)
            return
        
        # Process regular message
        self._process_complete_message(sender_nickname, message_content)
    
    def _handle_chunk(self, sender_nickname: str, chunk_message: str):
        """Handle a chunked message part"""
        import time
        
        try:
            # Parse chunk header: <PGP-CHUNK:message_id:chunk_num:total_chunks>
            header_end = chunk_message.find(">")
            if header_end == -1:
                return
                
            header = chunk_message[11:header_end]  # Remove <PGP-CHUNK:
            chunk_data = chunk_message[header_end + 1:]  # Content after >
            
            parts = header.split(":")
            if len(parts) != 3:
                return
                
            message_id, chunk_num, total_chunks = parts
            chunk_num = int(chunk_num)
            total_chunks = int(total_chunks)
            
            # Initialize pending message if not exists
            if message_id not in self.pending_chunks:
                self.pending_chunks[message_id] = {
                    "chunks": {},
                    "total": total_chunks,
                    "sender": sender_nickname,
                    "timestamp": time.time()
                }
            
            # Store chunk
            self.pending_chunks[message_id]["chunks"][chunk_num] = chunk_data
            
            # Check if we have all chunks
            pending = self.pending_chunks[message_id]
            if len(pending["chunks"]) == pending["total"]:
                # Reassemble message
                complete_message = ""
                for i in range(1, pending["total"] + 1):
                    complete_message += pending["chunks"][i]
                
                # Clean up
                del self.pending_chunks[message_id]
                
                # Process complete message
                self._process_complete_message(sender_nickname, complete_message)
            
        except Exception as e:
            if self.on_error_callback:
                self.on_error_callback(f"Failed to handle chunk from {sender_nickname}: {str(e)}")
    
    def _process_complete_message(self, sender_nickname: str, message_content: str):
        """Process a complete message (either single or reassembled)"""
        # First, try to decode the message if it's encoded
        decoded_message = self._decode_from_irc(message_content)
        
        # Check if it's a PGP encrypted message (either original format or decoded)
        if (self.PGP_MESSAGE_START in decoded_message and 
            self.PGP_MESSAGE_END in decoded_message):
            
            # Try to decrypt the message
            try:
                # Use the correct decrypt method - we'll need to prompt for passphrase
                # For now, we'll try with empty passphrase or handle this differently
                decrypt_result = self.pgp_handler.decrypt_message(decoded_message, "")
                
                if not decrypt_result or not decrypt_result.get('success'):
                    # If decryption failed, it might need a passphrase
                    # For testing, we'll show the encrypted message
                    if self.on_error_callback:
                        self.on_error_callback(f"Failed to decrypt message from {sender_nickname}: Passphrase may be required")
                    return
                
                decrypted_content = decrypt_result['decrypted_message']
                
                # Verify sender if we have their contact info
                contact = self.get_contact(sender_nickname)
                verified = False
                
                if contact:
                    # TODO: Add signature verification here
                    verified = True
                    contact.online = True
                    contact.last_seen = time.time()
                    
                # Create secure message object
                chat_message = SecureChatMessage(
                    sender=sender_nickname,
                    recipient=self.irc_client.nickname,
                    content=decrypted_content
                )
                chat_message.encrypted = True
                chat_message.verified = verified
                
                # Add to history
                if self.save_history:
                    self.message_history.append(chat_message)
                    
                # Notify callback
                if self.on_message_callback:
                    self.on_message_callback(chat_message)
                    
            except Exception as e:
                # Failed to decrypt - might not be for us or corrupted
                if self.on_error_callback:
                    self.on_error_callback(f"Failed to decrypt message from {sender_nickname}: {str(e)}")
        elif message_content.startswith("<PGP-ENCODED>") and message_content.endswith("</PGP-ENCODED>"):
            # This is an encoded PGP message, but decoding revealed it's not a standard PGP block
            # This might be a different format or corrupted
            if self.on_error_callback:
                self.on_error_callback(f"Received encoded message from {sender_nickname} but could not process it")
        else:
            # Plain text message - create unencrypted message object
            chat_message = SecureChatMessage(
                sender=sender_nickname,
                recipient=self.irc_client.nickname,
                content=message_content
            )
            
            # Add to history
            if self.save_history:
                self.message_history.append(chat_message)
                
            # Notify callback
            if self.on_message_callback:
                self.on_message_callback(chat_message)
    
    def _cleanup_old_chunks(self):
        """Clean up old incomplete chunks"""
        import time
        current_time = time.time()
        
        expired_ids = []
        for message_id, pending in self.pending_chunks.items():
            if current_time - pending["timestamp"] > self.chunk_timeout:
                expired_ids.append(message_id)
        
        for message_id in expired_ids:
            del self.pending_chunks[message_id]
                
    def _on_irc_connect(self, network: str, nickname: str):
        """Handle IRC connection"""
        # Mark all contacts as potentially online
        for contact in self.contacts.values():
            contact.online = False  # Will be updated when they send messages
            
    def _on_irc_disconnect(self):
        """Handle IRC disconnection"""
        # Mark all contacts as offline
        for contact in self.contacts.values():
            contact.online = False
            
    def _on_irc_error(self, error: str):
        """Handle IRC errors"""
        if self.on_error_callback:
            self.on_error_callback(f"IRC Error: {error}")
            
    def get_message_history(self, contact_nickname: str = None) -> List[SecureChatMessage]:
        """Get message history, optionally filtered by contact"""
        if contact_nickname:
            return [msg for msg in self.message_history 
                   if msg.sender == contact_nickname or msg.recipient == contact_nickname]
        return self.message_history.copy()
        
    def clear_message_history(self):
        """Clear all message history"""
        self.message_history.clear()
        
    def set_history_saving(self, enabled: bool):
        """Enable or disable message history saving"""
        self.save_history = enabled
        
    def get_connection_status(self):
        """Get IRC connection status"""
        return self.irc_client.get_connection_status()
        
    def is_connected(self) -> bool:
        """Check if connected to IRC"""
        return self.irc_client.connected
        
    # Callback setters
    def set_message_callback(self, callback: Callable[[SecureChatMessage], None]):
        """Set callback for incoming messages"""
        self.on_message_callback = callback
        
    def set_contact_online_callback(self, callback: Callable[[SecureChatContact], None]):
        """Set callback for contact coming online"""
        self.on_contact_online_callback = callback
        
    def set_contact_offline_callback(self, callback: Callable[[SecureChatContact], None]):
        """Set callback for contact going offline"""
        self.on_contact_offline_callback = callback
        
    def set_error_callback(self, callback: Callable[[str], None]):
        """Set callback for errors"""
        self.on_error_callback = callback
        
    # Contact management helpers
    def export_contacts(self) -> str:
        """Export contacts to JSON string"""
        contacts_data = {nick: contact.to_dict() 
                        for nick, contact in self.contacts.items()}
        return json.dumps(contacts_data, indent=2)
        
    def import_contacts(self, json_data: str):
        """Import contacts from JSON string"""
        try:
            contacts_data = json.loads(json_data)
            for nick, contact_data in contacts_data.items():
                contact = SecureChatContact.from_dict(contact_data)
                self.contacts[nick] = contact
        except Exception as e:
            raise ValueError(f"Failed to import contacts: {str(e)}")
            
    def get_available_networks(self):
        """Get available IRC networks"""
        return self.irc_client.get_available_networks()
        
    def add_custom_server(self, name: str, server: str, port: int, ssl: bool = True):
        """Add custom IRC server"""
        self.irc_client.add_custom_server(name, server, port, ssl)

