"""
Chat Module for PGP Tool
Handles IRC-based secure messaging with PGP encryption
"""

